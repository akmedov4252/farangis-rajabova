'use client';

import { useState, useMemo } from 'react';
import { DateRange } from "react-day-picker"
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend, LineChart, Line } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Droplet, Filter, Globe, BarChart as BarChartIcon, Calendar as CalendarIcon } from 'lucide-react';
import { ChartContainer, ChartTooltipContent, ChartLegend, ChartLegendContent } from '@/components/ui/chart';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, limit } from 'firebase/firestore';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format, parseISO, isValid, getYear, getMonth, startOfDay, endOfDay } from 'date-fns';
import { Skeleton } from './ui/skeleton';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar } from './ui/calendar';
import { cn } from '@/lib/utils';

const chartConfig = {
    waterVolume: { label: "Расход воды (м³/с)", color: "hsl(var(--chart-1))" },
    lossPercentage: { label: "Потери (%)", color: "hsl(var(--chart-2))" },
} as const;

export function RegionalWaterAnalysis() {
  const firestore = useFirestore();
  const distributionsQuery = useMemoFirebase(
    () => firestore ? query(collection(firestore, 'waterDistributions_log'), orderBy('distributionDate', 'desc'), limit(500)) : null,
    [firestore]
  );
  const { data: allData, isLoading: isDistributionsLoading } = useCollection<any>(distributionsQuery);

  const [selectedBasin, setSelectedBasin] = useState('all');
  const [selectedDirectorate, setSelectedDirectorate] = useState('all');
  const [selectedCanal, setSelectedCanal] = useState('all');
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);

  const [activeFilters, setActiveFilters] = useState({
    basin: 'all',
    directorate: 'all',
    canal: 'all',
    dateRange: undefined as DateRange | undefined,
  });

  const handleApplyFilters = () => {
    setActiveFilters({
      basin: selectedBasin,
      directorate: selectedDirectorate,
      canal: selectedCanal,
      dateRange: dateRange,
    });
  };

  const { uniqueCanalNames } = useMemo(() => {
    if (!allData) return { uniqueCanalNames: [] };
    const canalNames = new Set<string>();
    allData.forEach(item => {
      if (item.canalName) {
        canalNames.add(item.canalName);
      }
    });
    return {
      uniqueCanalNames: Array.from(canalNames).sort(),
    };
  }, [allData]);

  const filteredData = useMemo(() => {
    if (!allData) return [];
    return allData.filter(item => {
      const basinMatch = activeFilters.basin === 'all' || item.basin === activeFilters.basin;
      const directorateMatch = activeFilters.directorate === 'all' || item.directorate === activeFilters.directorate;
      const canalMatch = activeFilters.canal === 'all' || item.canalName === activeFilters.canal;
      
      let dateMatch = true;
      if (activeFilters.dateRange?.from) {
          try {
              const itemDate = parseISO(item.distributionDate);
              if (isValid(itemDate)) {
                  const from = startOfDay(activeFilters.dateRange.from);
                  const to = activeFilters.dateRange.to ? endOfDay(activeFilters.dateRange.to) : endOfDay(new Date()); // Default to now if 'to' is not set
                  dateMatch = itemDate >= from && itemDate <= to;
              } else {
                  dateMatch = false;
              }
          } catch {
              dateMatch = false;
          }
      }

      return basinMatch && directorateMatch && canalMatch && dateMatch;
    });
  }, [allData, activeFilters]);

  const {
    totalWaterVolume,
    averageLoss,
    canalChartData
  } = useMemo(() => {
    if (!filteredData || filteredData.length === 0) {
      return { totalWaterVolume: 0, averageLoss: 0, canalChartData: [] };
    }

    let totalVolume = 0;
    let totalLoss = 0;
    let validLossItems = 0;
    const canalMap = new Map<string, { totalVolume: number; count: number; totalLoss: number }>();

    filteredData.forEach(item => {
      if (typeof item.waterVolume === 'number') {
        totalVolume += item.waterVolume;
      }
      if (typeof item.lossPercentage === 'number') {
        totalLoss += item.lossPercentage;
        validLossItems++;
      }

      if (item.canalName) {
        const existing = canalMap.get(item.canalName) || { totalVolume: 0, count: 0, totalLoss: 0 };
        if (typeof item.waterVolume === 'number') {
            existing.totalVolume += item.waterVolume;
        }
        if (typeof item.lossPercentage === 'number') {
            existing.totalLoss += item.lossPercentage;
        }
        existing.count += 1;
        canalMap.set(item.canalName, existing);
      }
    });

    const avgLoss = validLossItems > 0 ? totalLoss / validLossItems : 0;

    const chartData = Array.from(canalMap.entries()).map(([name, data]) => ({
      name,
      waterVolume: data.count > 0 ? data.totalVolume / data.count : 0, // Average volume
      lossPercentage: data.count > 0 ? data.totalLoss / data.count : 0, // Average loss
    }));

    return {
      totalWaterVolume: totalVolume,
      averageLoss: avgLoss,
      canalChartData: chartData,
    };
  }, [filteredData]);

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-2">
        <h1 className="font-headline text-3xl font-bold tracking-tight">Анализ расхода воды в регионе</h1>
        <p className="text-muted-foreground">Обзор расхода воды и потерь в различных каналах.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Фильтры
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div className="flex flex-col gap-2">
             <label className="text-sm font-medium">Бассейн</label>
            <Select value={selectedBasin} onValueChange={setSelectedBasin}>
              <SelectTrigger>
                <SelectValue placeholder="Бассейн..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все бассейны</SelectItem>
                <SelectItem value="Сырдарья">Бассейн реки Сырдарья</SelectItem>
                <SelectItem value="Амударья">Бассейн реки Амударья</SelectItem>
                <SelectItem value="Зарафшон">Бассейн реки Зарафшан</SelectItem>
                <SelectItem value="Кофарнихон">Бассейн реки Кафирниган</SelectItem>
                <SelectItem value="Сурхоб">Бассейн реки Сурхоб</SelectItem>
              </SelectContent>
            </Select>
          </div>
           <div className="flex flex-col gap-2">
             <label className="text-sm font-medium">Управление</label>
            <Select value={selectedDirectorate} onValueChange={setSelectedDirectorate}>
              <SelectTrigger>
                <SelectValue placeholder="Управление..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все управления</SelectItem>
                <SelectItem value="Управление 1">Управление 1</SelectItem>
                <SelectItem value="Управление 2">Управление 2</SelectItem>
                <SelectItem value="Управление 3">Управление 3</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-2">
             <label className="text-sm font-medium">Канал</label>
            <Select value={selectedCanal} onValueChange={setSelectedCanal}>
              <SelectTrigger>
                <SelectValue placeholder="Канал..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все каналы</SelectItem>
                {uniqueCanalNames.map(canalName => (
                  <SelectItem key={canalName} value={canalName}>{canalName}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-col gap-2">
             <label className="text-sm font-medium">Диапазон дат</label>
            <Popover>
                <PopoverTrigger asChild>
                <Button
                    id="date"
                    variant={"outline"}
                    className={cn(
                    "w-full justify-start text-left font-normal",
                    !dateRange && "text-muted-foreground"
                    )}
                >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange?.from ? (
                    dateRange.to ? (
                        <>
                        {format(dateRange.from, "LLL dd, y")} -{" "}
                        {format(dateRange.to, "LLL dd, y")}
                        </>
                    ) : (
                        format(dateRange.from, "LLL dd, y")
                    )
                    ) : (
                    <span>Выберите дату</span>
                    )}
                </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange?.from}
                    selected={dateRange}
                    onSelect={setDateRange}
                    numberOfMonths={2}
                />
                </PopoverContent>
            </Popover>
          </div>

          <Button onClick={handleApplyFilters} className="w-full lg:col-span-4">Применить</Button>
        </CardContent>
      </Card>

       <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Общий расход воды</CardTitle>
            <Droplet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalWaterVolume.toLocaleString(undefined, { maximumFractionDigits: 2 })} м³/с</div>
            <p className="text-xs text-muted-foreground">по всем выбранным записям</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Средние потери</CardTitle>
            <Globe className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageLoss.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">по всем выбранным записям</p>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Последние записи о распределении воды</CardTitle>
          <CardDescription>Данные, введенные из планировщика распределения воды.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Бассейн</TableHead>
                <TableHead>Управление</TableHead>
                <TableHead>Канал</TableHead>
                <TableHead className="text-right">Расход воды (м³/с)</TableHead>
                <TableHead className="text-right">Потери (%)</TableHead>
                <TableHead className="text-right">Дата записи</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isDistributionsLoading && Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-5 w-20 ml-auto" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-5 w-16 ml-auto" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-5 w-32 ml-auto" /></TableCell>
                </TableRow>
              ))}
              {filteredData.length > 0 ? filteredData.slice(0, 10).map((item, index) => (
                <TableRow key={item.id || index}>
                  <TableCell className="font-medium">{item.basin}</TableCell>
                  <TableCell>{item.directorate}</TableCell>
                  <TableCell>{item.canalName}</TableCell>
                  <TableCell className="text-right">{typeof item.waterVolume === 'number' ? item.waterVolume.toLocaleString(undefined, { maximumFractionDigits: 2 }) : '-'}</TableCell>
                  <TableCell className="text-right">{typeof item.lossPercentage === 'number' ? `${item.lossPercentage.toFixed(1)}%` : '-'}</TableCell>
                  <TableCell className="text-right">{isValid(parseISO(item.distributionDate)) ? format(parseISO(item.distributionDate), 'dd.MM.yyyy HH:mm') : '-'}</TableCell>
                </TableRow>
              )) : !isDistributionsLoading && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">Нет данных для отображения.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle>Анализ расхода и потерь воды в каналах</CardTitle>
            <CardDescription>Сравнение среднего расхода воды и процента потерь в разных каналах.</CardDescription>
        </CardHeader>
        <CardContent>
            <ChartContainer config={chartConfig} className="h-[400px] w-full">
              <BarChart data={canalChartData} margin={{ top: 20, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="name" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} angle={-45} textAnchor="end" height={80} />
                <YAxis yAxisId="left" orientation="left" stroke="var(--color-waterVolume)" tickFormatter={(value) => `${value.toFixed(1)} м³/с`} />
                <YAxis yAxisId="right" orientation="right" stroke="var(--color-lossPercentage)" tickFormatter={(value) => `${value.toFixed(0)}%`} />
                <Tooltip cursor={{fill: 'hsl(var(--muted))'}} content={<ChartTooltipContent />} />
                <Legend />
                <Bar yAxisId="left" dataKey="waterVolume" fill="var(--color-waterVolume)" name="Средний расход воды" radius={4} />
                <Bar yAxisId="right" dataKey="lossPercentage" fill="var(--color-lossPercentage)" name="Средние потери" radius={4} />
              </BarChart>
            </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );
}
