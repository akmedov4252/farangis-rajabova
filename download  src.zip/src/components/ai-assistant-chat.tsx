'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { assistant } from '@/ai/flows/assistant-flow';

import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Send, User, Bot } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import placeholderImages from '@/lib/placeholder-images.json';
import { cn } from '@/lib/utils';

const formSchema = z.object({
  message: z.string().min(1, { message: 'Паём набояд холӣ бошад.' }),
});

type Message = {
  role: 'user' | 'model';
  content: string;
};

const userAvatar = placeholderImages.placeholderImages.find(p => p.id === "user-avatar");

export function AiAssistantChat() {
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<Message[]>([]);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      message: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoading(true);
    const userMessage: Message = { role: 'user', content: values.message };
    const newHistory = [...history, userMessage];
    setHistory(newHistory);
    form.reset();

    try {
      const chatHistoryForApi = newHistory.map(h => ({
        role: h.role,
        content: [{ text: h.content }],
      }));

      const response = await assistant({ history: chatHistoryForApi });
      
      const modelMessage: Message = { role: 'model', content: response };
      setHistory(prev => [...prev, modelMessage]);

    } catch (e) {
      console.error(e);
      const errorMessage: Message = { role: 'model', content: 'Бубахшед, хатогӣ рух дод. Лутфан, бори дигар кӯшиш кунед.' };
      setHistory(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="flex-1 flex flex-col">
      <CardContent className="flex-1 flex flex-col p-4 md:p-6">
        <ScrollArea className="flex-1 mb-4 pr-4">
          <div className="space-y-6">
            {history.length === 0 && (
                <div className="text-center text-muted-foreground pt-10">
                    <Bot className="mx-auto h-12 w-12 mb-4" />
                    <h3 className="text-lg font-semibold">Салом! Чӣ гуна кӯмак карда метавонам?</h3>
                    <p className="text-sm">Шумо метавонед дар бораи ҳосилнокии пахта, талафоти об дар каналҳо ва ё дигар мавзӯъҳо савол диҳед.</p>
                </div>
            )}
            {history.map((message, index) => (
              <div key={index} className={cn("flex items-start gap-4", message.role === 'user' ? 'justify-end' : '')}>
                {message.role === 'model' && (
                  <Avatar className="w-8 h-8 border">
                    <AvatarFallback><Bot size={20} /></AvatarFallback>
                  </Avatar>
                )}
                <div className={cn("max-w-md rounded-lg p-3", message.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary')}>
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                 {message.role === 'user' && (
                  <Avatar className="w-8 h-8 border">
                    <AvatarImage src={userAvatar?.imageUrl} />
                    <AvatarFallback>
                      <User size={20} />
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            {loading && (
                <div className="flex items-start gap-4">
                    <Avatar className="w-8 h-8 border">
                        <AvatarFallback><Bot size={20} /></AvatarFallback>
                    </Avatar>
                     <div className="max-w-md rounded-lg p-3 bg-secondary flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Фикр карда истодаам...</span>
                    </div>
                </div>
            )}
          </div>
        </ScrollArea>
        <div className="mt-auto">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-center gap-2">
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormControl>
                      <Input placeholder="Саволи худро нависед..." {...field} autoComplete="off" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" disabled={loading} size="icon">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                <span className="sr-only">Фиристодан</span>
              </Button>
            </form>
          </Form>
        </div>
      </CardContent>
    </Card>
  );
}
