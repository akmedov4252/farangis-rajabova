"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sun, Moon } from "lucide-react";
import { cn } from "@/lib/utils";

type Theme = "light" | "dark";

export function ThemeSwitcher() {
  const [theme, setTheme] = useState<Theme>("light");

  useEffect(() => {
    const storedTheme = localStorage.getItem("theme") as Theme | null;
    if (storedTheme) {
      setTheme(storedTheme);
      document.documentElement.classList.toggle("dark", storedTheme === "dark");
    }
  }, []);

  const handleThemeChange = (newTheme: Theme) => {
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    document.documentElement.classList.toggle("dark", newTheme === "dark");
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      <div
        className={cn(
          "rounded-lg border-2 p-4 cursor-pointer",
          theme === "light" ? "border-primary" : "border-transparent"
        )}
        onClick={() => handleThemeChange("light")}
      >
        <div className="flex items-center gap-2 mb-2">
          <Sun className="w-5 h-5" />
          <h4 className="font-semibold">Светлая</h4>
        </div>
        <div className="aspect-video p-2 bg-background rounded-md border">
            <div className="w-full h-2 rounded-lg bg-primary mb-2"></div>
            <div className="space-y-1">
                <div className="w-3/4 h-2 rounded-lg bg-muted-foreground/50"></div>
                <div className="w-1/2 h-2 rounded-lg bg-muted-foreground/30"></div>
            </div>
        </div>
      </div>
      <div
        className={cn(
          "rounded-lg border-2 p-4 cursor-pointer",
          theme === "dark" ? "border-primary" : "border-transparent"
        )}
        onClick={() => handleThemeChange("dark")}
      >
        <div className="flex items-center gap-2 mb-2">
          <Moon className="w-5 h-5" />
          <h4 className="font-semibold">Темная</h4>
        </div>
        <div className="aspect-video p-2 bg-zinc-900 rounded-md border border-zinc-700">
            <div className="w-full h-2 rounded-lg bg-primary mb-2"></div>
            <div className="space-y-1">
                <div className="w-3/4 h-2 rounded-lg bg-zinc-600"></div>
                <div className="w-1/2 h-2 rounded-lg bg-zinc-700"></div>
            </div>
        </div>
      </div>
    </div>
  );
}
