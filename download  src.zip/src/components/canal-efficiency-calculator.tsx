'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Button } from './ui/button';
import { Trash2, PlusCircle, AlertTriangle } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { cn } from '@/lib/utils';
import React from 'react';
import { useFieldArray } from 'react-hook-form';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';

const measurementPointSchema = z.object({
  distance: z.coerce.number().min(0, "Расстояние должно быть положительным."),
  flowRate: z.coerce.number().min(0, "Расход воды должен быть положительным."),
});

const formSchema = z.object({
  canalName: z.string().optional(),
  totalLength: z.coerce.number().optional(),
  points: z.array(measurementPointSchema).min(2, "Требуется как минимум две точки измерения."),
}).refine(data => {
    const sortedPoints = [...data.points].sort((a, b) => {
        if (a.distance < b.distance) return -1;
        if (a.distance > b.distance) return 1;
        if (a.flowRate > b.flowRate) return -1;
        if (a.flowRate < b.flowRate) return 1;
        return 0;
    });
    for (let i = 1; i < sortedPoints.length; i++) {
        if (sortedPoints[i].flowRate > sortedPoints[i-1].flowRate) {
            return false;
        }
    }
    return true;
}, {
    message: "Расход воды не может увеличиваться вниз по течению канала.",
    path: ["points"],
});


type FormValues = z.infer<typeof formSchema>;

const chartConfig = {
    efficiency: { label: "Эффективность (%)", color: "hsl(var(--chart-2))" },
} as const;

type AnalysisResults = {
    segments: any[];
    totalEfficiency: number;
    highestLossSegment: number | null;
    highestLossSegmentLabel: string;
};

export function CanalEfficiencyCalculator() {
  const [analysisResults, setAnalysisResults] = React.useState<AnalysisResults | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      canalName: 'Главный канал С-1',
      totalLength: 25,
      points: [
        { distance: 0, flowRate: 1.5 },
        { distance: 10, flowRate: 1.2 },
      ],
    },
    mode: 'onChange'
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "points"
  });

  // This effect will clear results if the form data changes after a calculation
  React.useEffect(() => {
    const subscription = form.watch(() => {
        setAnalysisResults(null);
    });
    return () => subscription.unsubscribe();
  }, [form]);
  
  const handleCalculate = (data: FormValues) => {
    const parsedPoints = data.points.map(p => ({
        distance: !isNaN(parseFloat(String(p.distance))) ? parseFloat(String(p.distance)) : 0,
        flowRate: !isNaN(parseFloat(String(p.flowRate))) ? parseFloat(String(p.flowRate)) : 0,
    }));
    
    const sortedPoints = [...parsedPoints].sort((a, b) => {
      if (a.distance < b.distance) return -1;
      if (a.distance > b.distance) return 1;
      if (a.flowRate > b.flowRate) return -1;
      if (a.flowRate < b.flowRate) return 1;
      return 0;
    });

    // Validate that flow rate doesn't increase downstream
    for (let i = 1; i < sortedPoints.length; i++) {
        if (sortedPoints[i].flowRate > sortedPoints[i - 1].flowRate) {
            form.setError("points", { 
                type: "manual", 
                message: "Расход воды не может увеличиваться вниз по течению канала." 
            });
            return; // Stop calculation
        }
    }
    // Clear previous error if validation passes
    form.clearErrors("points");

    const segments = [];
    let lowestEfficiency = 101;
    let lowestEfficiencySegmentIndex: number | null = null;
    let lowestEfficiencySegmentLabel = '';

    for (let i = 0; i < sortedPoints.length - 1; i++) {
        const startPoint = sortedPoints[i];
        const endPoint = sortedPoints[i+1];

        const segmentLength = endPoint.distance - startPoint.distance;
        if (segmentLength <= 0 && startPoint.distance === endPoint.distance && startPoint.flowRate === endPoint.flowRate) continue;


        const loss = startPoint.flowRate - endPoint.flowRate;
        const efficiency = startPoint.flowRate > 0 ? (endPoint.flowRate / startPoint.flowRate) * 100 : 0;
        
        const newSegment = {
            label: `${i + 1} → ${i + 2}`,
            startDistance: startPoint.distance,
            endDistance: endPoint.distance,
            length: segmentLength,
            loss: loss,
            efficiency: efficiency,
        };

        segments.push(newSegment);

        if (efficiency < lowestEfficiency) {
            lowestEfficiency = efficiency;
            lowestEfficiencySegmentIndex = segments.length - 1;
            lowestEfficiencySegmentLabel = newSegment.label;
        }
    }
    
    const totalEfficiency = sortedPoints.length > 1 && sortedPoints[0].flowRate > 0 
        ? (sortedPoints[sortedPoints.length-1].flowRate / sortedPoints[0].flowRate) * 100
        : 0;
        
    if (lowestEfficiency > 99.99) {
        lowestEfficiencySegmentIndex = null;
    }

    setAnalysisResults({
        segments,
        totalEfficiency: isNaN(totalEfficiency) ? 0 : totalEfficiency,
        highestLossSegment: lowestEfficiencySegmentIndex,
        highestLossSegmentLabel: lowestEfficiencySegmentLabel,
    });
  };

  const handleAddNewPoint = () => {
    const lastPoint = fields[fields.length - 1];
    const newDistance = lastPoint ? (Number(lastPoint.distance) || 0) + 10 : 0;
    const newFlowRate = lastPoint ? (Number(lastPoint.flowRate) || 0) * 0.9 : 1.0;
    append({ distance: newDistance, flowRate: parseFloat(newFlowRate.toFixed(3)) });
  };
  
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-6">
      <div>
        <Card>
            <CardHeader>
                <CardTitle>Данные канала и точки измерений</CardTitle>
                <CardDescription>
                    Введите расход воды в различных точках по длине канала.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleCalculate)} className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                            <FormField
                                control={form.control}
                                name="canalName"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Название канала</FormLabel>
                                    <FormControl>
                                    <Input placeholder="Например, Канал С-1" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="totalLength"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Общая длина (км)</FormLabel>
                                    <FormControl>
                                    <Input type="number" placeholder="Например, 25" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                        </div>
                        <Separator />

                        <h4 className="font-medium text-center">Точки измерений</h4>

                        <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                            {fields.map((field, index) => (
                            <div key={field.id} className="relative p-4 border rounded-lg bg-background">
                                <p className="absolute -top-3 left-3 bg-background px-2 text-sm font-medium text-muted-foreground">Точка {index + 1}</p>
                                <div className="grid grid-cols-[1fr_1fr_auto] gap-2 items-start">
                                    <FormField
                                        control={form.control}
                                        name={`points.${index}.distance`}
                                        render={({ field }) => (
                                            <FormItem>
                                            <FormLabel>Расстояние (км)</FormLabel>
                                            <FormControl>
                                                <Input type="number" step="0.1" {...field} />
                                            </FormControl>
                                            <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name={`points.${index}.flowRate`}
                                        render={({ field }) => (
                                            <FormItem>
                                            <FormLabel>Расход (м³/с)</FormLabel>
                                            <FormControl>
                                                <Input type="number" step="0.01" {...field} />
                                            </FormControl>
                                            <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        className="text-destructive hover:bg-destructive/10 mt-8"
                                        onClick={() => remove(index)}
                                        disabled={fields.length <= 2}
                                        aria-label="Удалить точку"
                                    >
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </div>
                            </div>
                            ))}
                        </div>

                        <Button
                            type="button"
                            variant="outline"
                            className="w-full mt-4"
                            onClick={handleAddNewPoint}
                        >
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Добавить точку измерения
                        </Button>
                         {form.formState.errors.points?.message && (
                            <p className="text-sm font-medium text-destructive">{form.formState.errors.points.message}</p>
                        )}
                        <Button type="submit" className="w-full" size="lg">
                            Рассчитать эффективность
                        </Button>
                    </form>
                </Form>
            </CardContent>
        </Card>
      </div>

      {analysisResults ? (
        <Card className="bg-secondary/50 flex flex-col">
            <CardHeader>
            <CardTitle className="font-headline">Результаты анализа</CardTitle>
            <CardDescription>Распределение эффективности по каждому участку канала.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 flex-grow">
                <div className="space-y-2">
                    <div className="flex justify-between items-baseline">
                        <p className="text-muted-foreground">Общая эффективность канала</p>
                        <p className="text-3xl font-bold text-primary">{analysisResults.totalEfficiency.toFixed(1)}%</p>
                    </div>
                </div>
                <Separator />
                <div>
                    <h4 className="font-medium mb-2">Анализ участков</h4>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Участок</TableHead>
                                <TableHead className="text-right">Потери (м³/с)</TableHead>
                                <TableHead className="text-right">Эффективность (%)</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {analysisResults.segments.length > 0 ? analysisResults.segments.map((seg, index) => (
                                <TableRow key={index} className={cn(analysisResults.highestLossSegment === index && 'bg-destructive/20')}>
                                    <TableCell className="font-medium">{seg.label}</TableCell>
                                    <TableCell className="text-right font-mono">{parseFloat(String(seg.loss)).toFixed(3)}</TableCell>
                                    <TableCell className="text-right font-mono">{parseFloat(String(seg.efficiency)).toFixed(1)}%</TableCell>
                                </TableRow>
                            )) : (
                                <TableRow>
                                    <TableCell colSpan={3} className="text-center text-muted-foreground">
                                        Введите данные для расчета.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
                {analysisResults.highestLossSegment !== null && (
                    <div className="flex items-start gap-3 rounded-lg border border-destructive/50 bg-destructive/10 p-3">
                        <AlertTriangle className="h-5 w-5 flex-shrink-0 text-destructive mt-1" />
                        <div>
                            <p className="font-semibold text-destructive-foreground">Самая низкая эффективность!</p>
                            <p className="text-sm text-muted-foreground">
                            Участок <strong>{analysisResults.highestLossSegmentLabel}</strong> имеет самую низкую эффективность.
                            </p>
                        </div>
                    </div>
                )}

                {analysisResults.segments.length > 0 && (
                    <div className="pt-4 border-t">
                        <h4 className="font-medium mb-4 text-center">Визуализация эффективности участков</h4>
                        <ChartContainer config={chartConfig} className="h-[250px] w-full">
                             <BarChart data={analysisResults.segments} margin={{ top: 20, right: 20, left: -10, bottom: 5 }}>
                                <CartesianGrid vertical={false} />
                                <XAxis dataKey="label" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
                                <YAxis domain={[0, 100]} tickFormatter={(val) => `${val}%`}/>
                                <Tooltip
                                    cursor={{ fill: 'hsl(var(--muted))' }}
                                    content={<ChartTooltipContent
                                        formatter={(value) => [`${(value as number).toFixed(2)}%`, "Эффективность"]}
                                        labelFormatter={(label) => `Участок: ${label}`}
                                    />}
                                />
                                <Bar dataKey="efficiency" fill="hsl(var(--chart-2))" radius={4} />
                            </BarChart>
                        </ChartContainer>
                    </div>
                )}
            </CardContent>
        </Card>
      ) : (
        <Card className="bg-secondary/50 flex flex-col items-center justify-center text-center">
            <CardHeader>
                <CardTitle className="font-headline">Результаты появятся здесь</CardTitle>
                <CardDescription>После ввода данных нажмите "Рассчитать".</CardDescription>
            </CardHeader>
        </Card>
      )}
    </div>
  );
}
