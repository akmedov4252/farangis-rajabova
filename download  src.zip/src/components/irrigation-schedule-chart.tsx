'use client';

import { useMemo, useState, useEffect } from 'react';
import { Line, LineChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, LabelList, Dot } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';
import { Droplet, Calendar, Coins } from 'lucide-react';
import { useLanguage } from '@/context/language-context';

export type IrrigationData = {
  name: string; // e.g., 'Apr-I', 'Apr-II'
  description: string; // e.g., 'Давраи гулкунӣ'
  waterVolume: number; // m³/ha
  month: string; // 'April'
  decade: number; // 1, 2, or 3
  dayOfMonth: number; // 5, 15, or 25
  hydroModule: number; // л/с дар 1.га
  startDate: string; // 'dd.MM'
  endDate: string; // 'dd.MM'
  durationDays: number;
};

type CropSchedule = {
  data: IrrigationData[];
  duration: number;
  seasonStartDate: string; 
  intervalDays: number; 
};

function createDecadeData(
    monthIndex: number, 
    decade: number, 
    waterVolume: number, 
    description: string,
    hydroModule: number,
    startDate: string,
    endDate: string,
    durationDays: number
): IrrigationData {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = monthNames[monthIndex];
  const decadeMap: { [key: number]: { name: string; day: number } } = {
    1: { name: 'I', day: 5 },
    2: { name: 'II', day: 15 },
    3: { name: 'III', day: 25 },
  };
  return {
    name: `${month}-${decadeMap[decade].name}`,
    description,
    waterVolume,
    month: month,
    decade: decade,
    dayOfMonth: decadeMap[decade].day,
    hydroModule,
    startDate,
    endDate,
    durationDays
  };
}

export const allCropsData: Record<string, CropSchedule> = {
  'Гандум': {
    data: [
      createDecadeData(4, 1, 700, 'Давраи нашъунамо', 0.68, '07.05', '18.05', 12),
      createDecadeData(4, 2, 800, 'Давраи нашъунамо', 0.77, '19.05', '30.05', 12),
      createDecadeData(4, 3, 800, 'Давраи гулкунӣ', 0.84, '31.05', '10.06', 11),
      createDecadeData(5, 1, 900, 'Пур шудани дон', 0.95, '11.06', '21.06', 11),
    ].filter(d => d.waterVolume > 0),
    duration: 130,
    seasonStartDate: '2024-03-20',
    intervalDays: 10,
  },
  'Юнучқа': {
    data: [
      createDecadeData(3, 1, 850, "Давраи нашъунамо", 0.41, '08.04', '01.05', 24),
      createDecadeData(4, 2, 850, "Давраи нашъунамо", 0.49, '02.05', '21.05', 20),
      createDecadeData(5, 3, 850, "Давраи нашъунамо", 0.58, '22.05', '07.06', 17),
      createDecadeData(5, 1, 850, "Давраи нашъунамо", 0.66, '08.06', '22.06', 15),
      createDecadeData(5, 2, 850, "Давраи нашъунамо", 0.70, '23.06', '06.07', 14),
      createDecadeData(6, 1, 850, "Давраи нашъунамо", 0.76, '07.07', '18.07', 13),
      createDecadeData(6, 2, 850, "Давраи нашъунамо", 0.98, '19.07', '28.07', 10),
      createDecadeData(7, 1, 850, "Давраи нашъунамо", 1.16, '29.07', '06.08', 9),
      createDecadeData(7, 2, 850, "Давраи нашъунамо", 0.98, '07.08', '16.08', 10),
      createDecadeData(8, 1, 850, "Давраи нашъунамо", 0.82, '17.08', '28.08', 12),
      createDecadeData(8, 2, 850, "Давраи нашъунамо", 0.76, '29.08', '10.09', 13),
      createDecadeData(8, 3, 850, "Давраи нашъунамо", 0.62, '11.09', '26.09', 16),
      createDecadeData(9, 1, 850, "Давраи нашъунамо", 0.52, '27.09', '15.10', 19),
    ].filter(d => d.waterVolume > 0),
    duration: 220,
    seasonStartDate: '2024-04-01',
    intervalDays: 15,
  },
  'Ҷуворимакка': {
    data: [
        createDecadeData(3, 3, 650, "Давраи нашъунамо", 0.75, '26.04', '05.05', 10),
        createDecadeData(4, 1, 700, "Давраи нашъунамо", 0.81, '06.05', '15.05', 10),
        createDecadeData(4, 2, 750, "Давраи нашъунамо", 0.87, '16.05', '25.05', 10),
        createDecadeData(4, 3, 800, "Давраи гулкунӣ", 1.03, '26.05', '03.06', 9),
        createDecadeData(5, 1, 800, "Давраи гулкунӣ", 1.16, '04.06', '11.06', 8),
        createDecadeData(5, 2, 800, "Давраи гулкунӣ", 1.32, '12.06', '18.06', 7),
        createDecadeData(5, 3, 800, "Пур шудани дон", 1.32, '19.06', '25.06', 7),
        createDecadeData(6, 1, 750, "Пур шудани дон", 1.24, '26.06', '02.07', 7),
        createDecadeData(6, 2, 750, "Пур шудани дон", 1.09, '03.07', '10.07', 8),
        createDecadeData(6, 3, 750, "Пухтан", 1.09, '11.07', '18.07', 8),
        createDecadeData(7, 1, 700, "Пухтан", 1.01, '19.07', '26.07', 8),
    ].filter(d => d.waterVolume > 0),
    duration: 120,
    seasonStartDate: '2024-04-26',
    intervalDays: 10,
  },
  'Боғот': {
    data: [
      createDecadeData(4, 1, 1200, "Давраи нашъунамо", 0.54, '03.05', '28.05', 26),
      createDecadeData(4, 3, 1200, "Давраи нашъунамо", 0.56, '29.05', '22.06', 25),
      createDecadeData(5, 3, 1200, "Давраи гулкунӣ", 0.69, '23.06', '12.07', 20),
      createDecadeData(6, 2, 1200, "Мевабандӣ", 0.66, '13.07', '02.08', 21),
      createDecadeData(7, 1, 1200, "Мевабандӣ", 0.58, '03.08', '26.08', 24),
      createDecadeData(8, 1, 1100, "Пухтан", 0.49, '27.08', '21.09', 26),
    ].filter(d => d.waterVolume > 0),
    duration: 140,
    seasonStartDate: '2024-05-03',
    intervalDays: 25,
  },
  'Токзор': {
    data: [
        createDecadeData(4, 2, 1250, "Давраи нашъунамо", 0.50, '09.05', '06.06', 29),
        createDecadeData(5, 1, 1300, "Давраи нашъунамо", 0.56, '07.06', '03.07', 27),
        createDecadeData(5, 1, 1300, "Давраи гулкунӣ", 0.63, '04.07', '27.07', 24),
        createDecadeData(6, 3, 1300, "Мевабандӣ", 0.58, '28.07', '19.08', 26),
        createDecadeData(7, 3, 1300, "Пухтан", 0.46, '20.08', '21.09', 33),
    ].filter(d => d.waterVolume > 0),
    duration: 135,
    seasonStartDate: '2024-05-09',
    intervalDays: 28,
  },
  'Сабзавот': {
    data: [
        createDecadeData(2, 2, 650, "Давраи нашъунамо", 0.63, '18.03', '29.03', 12),
        createDecadeData(3, 1, 450, "Давраи нашъунамо", 0.52, '06.04', '15.04', 10),
        createDecadeData(3, 3, 600, "Давраи нашъунамо", 0.77, '25.04', '03.05', 9),
        createDecadeData(4, 1, 600, "Давраи гулкунӣ", 0.77, '04.05', '12.05', 9),
        createDecadeData(4, 2, 600, "Давраи гулкунӣ", 0.87, '13.05', '20.05', 8),
        createDecadeData(4, 3, 600, "Давраи гулкунӣ", 0.99, '21.05', '27.05', 7),
        createDecadeData(5, 1, 600, "Мевабандӣ", 0.99, '28.05', '03.06', 7),
        createDecadeData(5, 2, 650, "Мевабандӣ", 1.07, '04.06', '10.06', 7),
        createDecadeData(5, 3, 650, "Мевабандӣ", 1.25, '11.06', '16.06', 6),
        createDecadeData(6, 1, 650, "Пухтан", 1.25, '17.06', '22.06', 6),
        createDecadeData(6, 2, 650, "Пухтан", 1.25, '23.06', '28.06', 6),
        createDecadeData(6, 3, 650, "Пухтан", 1.25, '29.06', '04.07', 6),
        createDecadeData(7, 1, 650, "Пухтан", 1.07, '05.07', '11.07', 7),
        createDecadeData(7, 2, 650, "Пухтан", 1.07, '12.07', '18.07', 7),
        createDecadeData(7, 3, 650, "Пухтан", 1.07, '19.07', '25.07', 7),
        createDecadeData(8, 1, 650, "Пухтан", 1.07, '26.07', '01.08', 7),
        createDecadeData(8, 2, 650, "Пухтан", 1.07, '02.08', '08.08', 7),
        createDecadeData(8, 3, 650, "Пухтан", 0.94, '09.08', '16.08', 8),
        createDecadeData(9, 1, 650, "Пухтан", 0.94, '17.08', '24.08', 8),
    ].filter(d => d.waterVolume > 0),
    duration: 160,
    seasonStartDate: '2024-03-18',
    intervalDays: 8,
  },
  'Полезӣ': {
    data: [
        createDecadeData(3, 2, 650, "Давраи нашъунамо", 0.63, '12.04', '23.04', 12),
        createDecadeData(4, 3, 650, "Давраи нашъунамо", 0.63, '21.05', '01.06', 12),
        createDecadeData(5, 1, 650, "Давраи гулкунӣ", 0.63, '04.06', '15.06', 12),
        createDecadeData(5, 2, 650, "Давраи гулкунӣ", 0.84, '16.06', '24.06', 9),
        createDecadeData(5, 3, 650, "Мевабандӣ", 1.07, '25.06', '01.07', 7),
        createDecadeData(6, 1, 650, "Мевабандӣ", 1.07, '02.07', '08.07', 7),
        createDecadeData(6, 2, 650, "Мевабандӣ", 1.07, '09.07', '15.07', 7),
        createDecadeData(6, 3, 650, "Пухтан", 0.94, '16.07', '23.07', 8),
        createDecadeData(7, 1, 750, "Пухтан", 0.87, '24.07', '02.08', 10),
    ].filter(d => d.waterVolume > 0),
    duration: 110,
    seasonStartDate: '2024-04-12',
    intervalDays: 10,
  },
  'Киштзори назди работ': {
    data: [
        createDecadeData(3, 3, 650, "Давраи нашъунамо", 0.75, '26.04', '05.05', 10),
        createDecadeData(4, 1, 700, "Давраи нашъунамо", 0.81, '06.05', '15.05', 10),
        createDecadeData(4, 2, 750, "Давраи гулкунӣ", 0.87, '16.05', '25.05', 10),
        createDecadeData(4, 3, 850, "Давраи гулкунӣ", 0.98, '26.05', '04.06', 10),
        createDecadeData(5, 1, 850, "Мевабандӣ", 1.09, '05.06', '13.06', 9),
        createDecadeData(5, 2, 850, "Мевабандӣ", 1.23, '14.06', '21.06', 8),
        createDecadeData(5, 3, 850, "Мевабандӣ", 1.23, '22.06', '29.06', 8),
        createDecadeData(6, 1, 850, "Пухтан", 1.41, '30.06', '06.07', 7),
        createDecadeData(6, 2, 850, "Пухтан", 0.89, '07.07', '17.07', 11),
        createDecadeData(6, 3, 850, "Пухтан", 0.76, '18.07', '30.07', 13),
        createDecadeData(7, 1, 850, "Пухтан", 0.70, '31.07', '13.08', 14),
        createDecadeData(7, 2, 800, "Пухтан", 0.62, '14.08', '28.08', 15),
        createDecadeData(8, 1, 750, "Пухтан", 0.54, '29.08', '13.09', 16),
        createDecadeData(8, 2, 750, "Пухтан", 0.51, '14.09', '30.09', 17),
        createDecadeData(9, 1, 700, "Пухтан", 0.41, '01.10', '20.10', 20),
    ].filter(d => d.waterVolume > 0),
    duration: 180,
    seasonStartDate: '2024-04-26',
    intervalDays: 10,
  },
};


const chartConfig = {
  waterVolume: { label: "Объем воды (м³/га)", color: "hsl(var(--chart-1))" },
} as const;

const PRICE_PER_CUBIC_METER = 0.05; // Условная цена за 1 м³ воды в сомони

const CustomDot = (props: any) => {
    const { cx, cy, stroke } = props;
    return (
      <Dot cx={cx} cy={cy} r={5} fill={stroke} stroke="#fff" strokeWidth={2} />
    );
};

export function IrrigationScheduleChart({ selectedCrop }: { selectedCrop: string }) {
  const [formattedTotalWater, setFormattedTotalWater] = useState<string | null>(null);
  const [formattedTotalCost, setFormattedTotalCost] = useState<string | null>(null);
  const { t, locale } = useLanguage();

  const cropInfo = allCropsData[selectedCrop] || allCropsData['Гандум'];
  const { data: chartData, duration: seasonDuration } = cropInfo;

  const { totalWater, totalCost } = useMemo(() => {
    const totalWater = chartData.reduce((acc, item) => acc + item.waterVolume, 0);
    const totalCost = totalWater * PRICE_PER_CUBIC_METER;
    return { totalWater, totalCost };
  }, [chartData]);

  useEffect(() => {
    // This effect runs only on the client, after hydration
    setFormattedTotalWater(new Intl.NumberFormat('ru-RU').format(totalWater));
    setFormattedTotalCost(new Intl.NumberFormat('ru-RU').format(totalCost));
  }, [totalWater, totalCost]);
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Droplet /> {t('chart.title', { crop: selectedCrop })}</CardTitle>
        <CardDescription>{t('chart.description', { crop: selectedCrop })}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            <Card className="bg-secondary/50 p-4">
                <CardHeader className="p-2">
                    <CardDescription className="flex items-center justify-center gap-2 text-sm">
                        <Droplet className="w-4 h-4" /> {t('chart.totalConsumption')}
                    </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                    <p className="text-2xl font-bold">{formattedTotalWater || '...'} <span className="text-sm font-normal text-muted-foreground">{t('chart.consumptionUnit')}</span></p>
                </CardContent>
            </Card>
             <Card className="bg-secondary/50 p-4">
                <CardHeader className="p-2">
                    <CardDescription className="flex items-center justify-center gap-2 text-sm">
                        <Calendar className="w-4 h-4" /> {t('chart.seasonDuration')}
                    </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                    <p className="text-2xl font-bold">~{seasonDuration} <span className="text-sm font-normal text-muted-foreground">{t('chart.durationUnit')}</span></p>
                </CardContent>
            </Card>
            <Card className="bg-secondary/50 p-4">
                <CardHeader className="p-2">
                    <CardDescription className="flex items-center justify-center gap-2 text-sm">
                        <Coins className="w-4 h-4" /> {t('chart.estimatedCost')}
                    </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                    <p className="text-2xl font-bold">{formattedTotalCost || '...'} <span className="text-sm font-normal text-muted-foreground">{t('chart.costUnit')}</span></p>
                </CardContent>
            </Card>
        </div>
        <ChartContainer config={chartConfig} className="h-[350px] w-full">
          <LineChart data={chartData} margin={{ top: 30, right: 30, left: 0, bottom: 5 }}>
            <CartesianGrid vertical={false} strokeDasharray="3 3"/>
            <XAxis dataKey="name" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} interval={0} angle={-45} textAnchor="end" height={60} />
            <YAxis
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              fontSize={12}
              tickFormatter={(value) => `${value}`}
              label={{ value: t('chart.yAxisLabel'), angle: -90, position: 'insideLeft', offset: 10 }}
            />
            <Tooltip
              cursor={{ stroke: 'hsl(var(--muted))', strokeDasharray: '3 3' }}
              content={
                <ChartTooltipContent
                  formatter={(value, name, props) => {
                    return (
                        <>
                         <div className="font-semibold">{props.payload.name}: {Number(value).toFixed(2)} {t('chart.consumptionUnit')}</div>
                         <div className="text-xs text-muted-foreground">{props.payload.description}</div>
                        </>
                    )
                  }}
                  labelFormatter={(label, payload) => {
                    if (payload && payload.length) {
                      return `${t('chart.decade')}: ${payload[0].payload.name}`
                    }
                    return label;
                  }}
                />
              }
            />
            <Line dataKey="waterVolume" type="monotone" stroke="var(--color-waterVolume)" strokeWidth={2} activeDot={{ r: 8 }} dot={<CustomDot />}>
               <LabelList dataKey="waterVolume" position="top" offset={10} fontSize={12} formatter={(value: number) => value.toFixed(0)} />
            </Line>
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
