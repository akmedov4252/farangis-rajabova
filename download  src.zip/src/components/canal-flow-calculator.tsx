'use client';

import React, { useState, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Image from 'next/image';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Button } from './ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { ChevronsUpDown, ArrowLeft } from 'lucide-react';
import placeholderImages from '@/lib/placeholder-images.json';
import { cn } from '@/lib/utils';


const formSchema = z.object({
  topWidth: z.coerce.number().min(0, "Ширина должна быть положительной."),
  bottomWidth: z.coerce.number().min(0, "Ширина должна быть положительной."),
  depth: z.coerce.number().min(0, "Глубина должна быть положительной."),
  velocity: z.coerce.number().min(0, "Скорость должна быть положительной."),
}).refine(data => data.topWidth >= data.bottomWidth, {
    message: "Верхняя ширина должна быть больше или равна нижней.",
    path: ["topWidth"],
});

type FormValues = z.infer<typeof formSchema>;

type CanalType = 'small_earth' | 'large_concrete' | 'mountain_river';

const canalTypes = [
  {
    id: 'small_earth' as CanalType,
    name: 'Малый земляной канал',
    description: 'Типичные каналы для распределения воды на фермах.',
    imageUrl: placeholderImages.placeholderImages.find(p => p.id === 'canal-small-earth')?.imageUrl,
    imageHint: 'small earth canal',
    defaults: { topWidth: 2, bottomWidth: 1, depth: 0.8, velocity: 0.5 },
  },
  {
    id: 'large_concrete' as CanalType,
    name: 'Большой бетонный канал',
    description: 'Магистральные сети с гладкой поверхностью и быстрым течением.',
    imageUrl: placeholderImages.placeholderImages.find(p => p.id === 'canal-large-concrete')?.imageUrl,
    imageHint: 'large concrete canal',
    defaults: { topWidth: 8, bottomWidth: 6, depth: 2.5, velocity: 1.5 },
  },
  {
    id: 'mountain_river' as CanalType,
    name: 'Горная река',
    description: 'Естественные потоки с крутым уклоном и высокой скоростью.',
    imageUrl: placeholderImages.placeholderImages.find(p => p.id === 'canal-mountain-river')?.imageUrl,
    imageHint: 'mountain river',
    defaults: { topWidth: 15, bottomWidth: 10, depth: 1.2, velocity: 2.0 },
  },
];


export function CanalFlowCalculator() {
  const [selectedCanal, setSelectedCanal] = useState<CanalType | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    mode: 'onChange'
  });

  const handleSelectCanal = (canalType: CanalType) => {
    const selected = canalTypes.find(c => c.id === canalType);
    if (selected) {
      form.reset(selected.defaults);
    }
    setSelectedCanal(canalType);
  };
  
  const watchedValues = form.watch();
  const { topWidth, bottomWidth, depth, velocity } = watchedValues;
    
  const results = useMemo(() => {
    if (topWidth < bottomWidth || depth <= 0 || velocity < 0) {
        return { area: 0, flowRate: 0, hourlyVolume: 0 };
    }

    const area = depth * (topWidth + bottomWidth) / 2;
    const flowRate = area * velocity;
    const hourlyVolume = flowRate * 3600;

    return {
        area: isNaN(area) ? 0 : area,
        flowRate: isNaN(flowRate) ? 0 : flowRate,
        hourlyVolume: isNaN(hourlyVolume) ? 0 : hourlyVolume,
    };
  }, [topWidth, bottomWidth, depth, velocity]);

  if (!selectedCanal) {
    return (
      <div className="pt-6">
        <h3 className="text-lg font-semibold text-center mb-4">Выберите тип канала или реки</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {canalTypes.map((canal) => (
            <Card 
              key={canal.id} 
              onClick={() => handleSelectCanal(canal.id)}
              className="cursor-pointer hover:shadow-lg hover:border-primary transition-all flex flex-col"
            >
              <div className="relative h-40 w-full">
                <Image
                  src={canal.imageUrl || ''}
                  alt={canal.name}
                  data-ai-hint={canal.imageHint}
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-xl">{canal.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground">{canal.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
      <div className="flex flex-col gap-4">
        <Button variant="ghost" onClick={() => setSelectedCanal(null)} className="self-start">
            <ArrowLeft className="mr-2" />
            Назад к выбору типа
        </Button>
        <Form {...form}>
            <form className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <FormField control={form.control} name="topWidth" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Верхняя ширина (B_top), м</FormLabel>
                            <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                    <FormField control={form.control} name="bottomWidth" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Нижняя ширина (B_bot), м</FormLabel>
                            <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                </div>
                 <FormField control={form.control} name="depth" render={({ field }) => (
                    <FormItem>
                        <FormLabel>Глубина воды (h), м</FormLabel>
                        <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                        <FormMessage />
                    </FormItem>
                )} />
                <FormField control={form.control} name="velocity" render={({ field }) => (
                    <FormItem>
                        <FormLabel>Скорость течения (V), м/с</FormLabel>
                        <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                        <FormMessage />
                    </FormItem>
                )} />
            </form>
        </Form>
      </div>

      <Card className="bg-secondary/50">
        <CardHeader>
          <CardTitle className="font-headline">Результаты</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="space-y-3">
                 <div className="flex justify-between items-baseline text-sm">
                    <p className="text-muted-foreground">Площадь сечения (A)</p>
                    <p className="font-mono">{results.area.toFixed(3)} м²</p>
                </div>
                <Separator />
                <div className="flex justify-between items-baseline">
                    <p className="text-muted-foreground">Расход воды (Q)</p>
                    <p className="text-3xl font-bold text-primary">{results.flowRate.toFixed(3)} м³/с</p>
                </div>
                 <Separator />
                <div className="flex justify-between items-baseline">
                    <p className="text-muted-foreground">Объем воды в час</p>
                    <p className="text-2xl font-bold text-accent">{results.hourlyVolume.toLocaleString(undefined, {maximumFractionDigits: 0})} м³/час</p>
                </div>
            </div>
            
            <Collapsible open={isOpen} onOpenChange={setIsOpen}>
                <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-center gap-2 mt-4">
                        <ChevronsUpDown className="h-4 w-4" />
                        {isOpen ? "Скрыть формулу" : "Подробнее"}
                    </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-4 pt-4">
                     <div className="text-sm text-muted-foreground p-4 bg-background/50 rounded-lg border">
                        <h4 className="font-semibold text-foreground mb-2">Используемые формулы</h4>
                        
                        <p className="font-medium mt-4">1. Площадь сечения (A) для трапеции:</p>
                        <pre className="mt-1 p-2 bg-muted rounded-md text-xs whitespace-pre-wrap">A = ((Верхняя ширина + Нижняя ширина) / 2) * Глубина</pre>
                        
                        <p className="font-medium mt-4">2. Расход воды (Q):</p>
                        <pre className="mt-1 p-2 bg-muted rounded-md text-xs">Q = Площадь * Скорость</pre>

                         <p className="font-medium mt-4">3. Объем воды в час:</p>
                        <pre className="mt-1 p-2 bg-muted rounded-md text-xs">Объем = Расход (Q) * 3600</pre>
                        
                        <Separator className="my-4"/>
                        <p className="font-semibold">Пример расчета:</p>
                        <p className="text-xs mt-2">
                            Если: Верх. ширина=4м, Ниж. ширина=2м, Глубина=2м, Скорость=1.5м/с
                        </p>
                        <ul className="list-disc list-inside mt-2 space-y-1 text-xs">
                            <li><b>Площадь:</b> ((4 + 2) / 2) * 2 = 6 м²</li>
                            <li><b>Расход:</b> 6 м² * 1.5 м/с = 9 м³/с</li>
                            <li><b>Объем в час:</b> 9 * 3600 = 32,400 м³</li>
                        </ul>
                    </div>
                </CollapsibleContent>
            </Collapsible>

        </CardContent>
      </Card>
    </div>
  );
}
