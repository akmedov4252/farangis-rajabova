'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { CardContent } from '@/components/ui/card';
import { Button } from './ui/button';
import { useFirestore, useUser } from '@/firebase';
import { addDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { collection, addDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { Calendar as CalendarIcon, Loader2 } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar } from './ui/calendar';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Slider } from './ui/slider';

const distributionFormSchema = z.object({
  basin: z.string().min(1, "Название бассейна обязательно."),
  directorate: z.string().min(1, "Название управления обязательно."),
  canalName: z.string().min(1, "Название канала обязательно."),
  waterVolume: z.coerce.number().min(0, "Расход воды должен быть положительным."),
  lossPercentage: z.coerce.number().min(0).max(100),
  distributionDate: z.date({ required_error: "Дата распределения обязательна." }),
});

type DistributionFormValues = z.infer<typeof distributionFormSchema>;


export function WaterDistributionPlanner() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const firestore = useFirestore();
  const { user } = useUser();
  

  const distributionForm = useForm<DistributionFormValues>({
    resolver: zodResolver(distributionFormSchema),
    defaultValues: {
      basin: 'Сырдарья',
      directorate: 'Управление 1',
      canalName: '',
      waterVolume: 1.5,
      lossPercentage: 15,
      distributionDate: new Date(),
    },
  });


  const handleDistributionSave = async (values: DistributionFormValues) => {
    if (!user) {
      toast({ variant: "destructive", title: "Ошибка", description: "Для сохранения необходимо войти в систему." });
      return;
    }
    if (!firestore) {
       toast({ variant: "destructive", title: "Ошибка", description: "Не удалось подключиться к базе данных." });
      return;
    }
    setLoading(true);

    const waterDistributionData = {
      ...values,
      distributionDate: values.distributionDate.toISOString(),
      userId: user.uid, // Track who saved it
    };
    
    try {
      const collectionRef = collection(firestore, `waterDistributions_log`);
      addDocumentNonBlocking(collectionRef, waterDistributionData);
      
      toast({ title: "Данные сохранены!", description: `Распределение воды для '${values.canalName}' сохранено.` });
      
      distributionForm.reset({
        ...distributionForm.getValues(),
        canalName: '',
        waterVolume: 1.5,
        lossPercentage: 15,
        distributionDate: new Date(),
      });
    } catch (err: any) {
       toast({ variant: "destructive", title: "Ошибка при сохранении", description: err.message || "Пожалуйста, проверьте правила безопасности." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <CardContent>
        <Form {...distributionForm}>
            <form onSubmit={distributionForm.handleSubmit(handleDistributionSave)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <FormField control={distributionForm.control} name="basin" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Бассейн</FormLabel>
                            <FormControl><Input placeholder="Введите название бассейна" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                    <FormField control={distributionForm.control} name="directorate" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Управление</FormLabel>
                             <FormControl><Input placeholder="Введите название управления" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                    <FormField control={distributionForm.control} name="canalName" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Канал</FormLabel>
                            <FormControl><Input placeholder="Введите название канала" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
                    <FormField control={distributionForm.control} name="distributionDate" render={({ field }) => (
                        <FormItem className="flex flex-col">
                            <FormLabel>Дата распределения</FormLabel>
                            <Popover>
                                <PopoverTrigger asChild>
                                <FormControl>
                                    <Button variant={"outline"} className={cn("w-full justify-start text-left font-normal",!field.value && "text-muted-foreground")}>
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {field.value ? format(field.value, "PPP") : <span>Выберите дату</span>}
                                    </Button>
                                </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                <Calendar mode="single" selected={field.value} onSelect={(date) => {if (date) field.onChange(date);}} initialFocus />
                                </PopoverContent>
                            </Popover>
                            <FormMessage />
                        </FormItem>
                    )} />
                    <FormField control={distributionForm.control} name="waterVolume" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Расход воды (м³/с)</FormLabel>
                            <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                    <FormField control={distributionForm.control} name="lossPercentage" render={({ field }) => (
                        <FormItem>
                        <FormLabel>Процент потерь (%)</FormLabel>
                        <FormControl>
                          <div className="flex items-center gap-4">
                            <Slider min={0} max={100} step={1} onValueChange={(value) => distributionForm.setValue('lossPercentage', value[0])} value={[field.value]} className="flex-1" />
                            <span className="w-16 text-right font-mono">{field.value.toFixed(0)}%</span>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                </div>
                 <div className="flex justify-end pt-4">
                    <Button type="submit" disabled={loading || !user} size="lg">
                        {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Сохранить распределение
                    </Button>
                </div>
            </form>
        </Form>
    </CardContent>
  );
}
