'use client';

import { useState, useMemo, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format, addDays, parseISO } from 'date-fns';
import { generateWaterDistributionPlan, type WaterDistributionInput, type WaterDistributionOutput } from '@/ai/flows/generate-water-distribution-plan';

import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, CalendarDays, BarChart, FileText, Calendar as CalendarIcon, Wheat, Leaf, Trash2 } from 'lucide-react';
import { useAuth, useFirestore, useUser, useCollection, useMemoFirebase, deleteDocumentNonBlocking } from '@/firebase';
import { addDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { collection, doc, query, where, orderBy } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar } from './ui/calendar';
import { cn } from '@/lib/utils';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { useLanguage } from '@/context/language-context';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Skeleton } from './ui/skeleton';
import { useCrop } from '@/context/crop-context';
import placeholderImages from '@/lib/placeholder-images.json';


const crops = [
  { id: 'Пшеница', name: 'Пшеница', name_tj: 'Гандум', water: '450-650мм', icon: <Wheat className="w-8 h-8 mb-2 text-yellow-500" /> },
  { id: 'Кукуруза', name: 'Кукуруза', name_tj: 'Ҷуворимакка', water: '500-800мм', icon: (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 mb-2 text-yellow-400" viewBox="0 0 24 24" fill="currentColor"><path d="M13 2.05c.6-.03 1.22.08 1.76.32.54.24.97.58 1.25.99.3.43.46.92.49 1.43-.09.74-.46 1.34-1.01 1.76-.55.42-1.25.6-2 .49-.76-.11-1.35-.59-1.5-1.34C11.89 4.93 12.4 2.08 13 2.05zM6.88 5.61c.4-.11.8-.11 1.2.02.39.13.73.37.99.69.26.32.43.7.49 1.1-.18.67-.62 1.18-1.22 1.43-.6.25-1.28.16-1.82-.2C5.97 8.22 5.89 7.42 6.1 6.64c.2-.78.53-1.05.78-1.03zM18.06 9.47c.59.21 1.05.6 1.32 1.1.27.5.38 1.07.31 1.65-.21.73-.78 1.26-1.48 1.48-.7.22-1.45.03-2.01-.49-.56-.52-.84-1.27-.72-2.02.13-.75.64-1.32 1.35-1.53.53-.15 1.05-.13 1.53-.19zM20.95 16c.03.6-.08 1.22-.32 1.76-.24.54-.58.97-.99 1.25-.43.3-.92.46-1.43.49-.74-.09-1.34-.46-1.76-1.01-.42-.55-.6-1.25-.49-2 .11-.76.59-1.35 1.34-1.5.77-.16 1.56.2 1.87.82.31.62.43 1.27.78 1.19zM12 7.08c.55.03 1.11-.08 1.58-.32.48-.24.84-.58 1.08-.99.25-.43.38-.92.4-1.43-.08-.74-.42-1.34-.93-1.76-.5-.42-1.16-.6-1.83-.49-.7.11-1.23.59-1.37 1.34-.14.75.14 1.53.7 2.02.56.49 1.27.71 1.97.63zM8.97 10.75c.03.55-.08 1.11-.32 1.58-.24.48-.58.84-.99 1.08-.43.25-.92.38-1.43.4-.74-.08-1.34-.42-1.76-.93-.42-.5-.6-1.16-.49-1.83.11-.7.59-1.23 1.34-1.37.75-.14 1.53.14 2.02.7.49.56.71 1.27.63 1.97z"/> </svg>
    ), },
  { id: 'Соя', name: 'Соя', name_tj: 'Лубиё', water: '450-700мм', icon: (
     <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 mb-2 text-green-600" viewBox="0 0 24 24" fill="currentColor"><path d="M16.9 8.35c-2.43-1.8-5.33-2.3-8.23-1.52L6.8 9.5c.34-2.8 2.2-5.08 4.63-6.15.54-.23 1.1-.4 1.68-.51 1.1-.2 2.24-.1 3.27.22.5.15 1 .38 1.45.68-.78 1.1-1.12 2.37-1.13 3.6-.01 1.25.33 2.5 1.14 3.53-1.33.2-2.65.03-3.84-.52zM15.4 12.6c-.03.46-.03.92-.02 1.38.1 3.53-2.3 6.65-5.63 7.58-.57.16-1.15.25-1.74.25-1.63 0-3.2-.5-4.5-1.52-1.3-1.04-2-2.5-2-4.13 0-.6.1-1.2.3-1.75 2.13.9 4.5.9 6.65 0 .4-.16.8-.36 1.17-.6 1.1-2.43.8-5.33-1-7.7-2.14-2.8-5.4-4.5-8.8-4.5C2.65 1.5 1.1 2.3.3 3.55c1.33.32 2.55.93 3.6 1.72 2.8 2.13 4.5 5.4 4.5 8.8 0 1.9-.5 3.75-1.4 5.35-1.2 2.1-3 3.6-5.1 4.3-1 .33-2.05.5-3.1.5-.6 0-1.2-.07-1.8-.2-2.5-2.1-4-5.2-4-8.5 0-3.9 2.1-7.4 5.2-9.4C7.7.4 9.8 0 12 0c3.2 0 6.2 1.2 8.5 3.5.7.7 1.3 1.5 1.7 2.4-2.5 1.1-4.2 3.5-4.2 6.3.01.2 0 .4.01.6.8-.4 1.7-.6 2.6-.6.8 0 1.6.1 2.4.4.8.3 1.5.7 2.1 1.2.6.5 1.1 1.2 1.4 2-.3-1.3-.8-2.5-1.6-3.6z"/> </svg>
    ), },
  { id: 'Юнучка', name: 'Юнучка', name_tj: 'Юнучқа', water: '900-1100мм', icon: <Leaf className="w-8 h-8 mb-2 text-green-500" /> },
  { id: 'Боғот', name: 'Боғот', name_tj: 'Боғот', water: '500-700мм', icon: (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 mb-2 text-red-500" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C9.24 2 7 4.24 7 7s2.24 5 5 5 5-2.24 5-5S14.76 2 12 2zm0 8c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm-6 3c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3zm0 4c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm12-4c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3zm0 4c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zM12 13c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3zm0 4c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"/></svg>
  ), },
  { id: 'Токзор', name: 'Токзор', name_tj: 'Токзор', water: '450-650мм', icon: (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 mb-2 text-purple-500" viewBox="0 0 24 24" fill="currentColor"><path d="M19 8.5c0-1.93-1.57-3.5-3.5-3.5S12 6.57 12 8.5c0 1.83 1.37 3.34 3.16 3.48l-1.8 5.41c-2.4-.6-4.36-2.56-4.96-4.96L6.52 9.3c.14-1.79 1.65-3.3 3.48-3.16 1.93.15 3.5 1.72 3.5 3.66h-2c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5.67 1.5 1.5 1.5c.34 0 .66-.11.92-.3l.79 2.37c-.6.37-1.29.53-2 .43-1.8-.25-3.23-1.7-3.47-3.5C6.38 8.08 7.92 6.62 9.77 6.5c1.86-.12 3.53 1.15 3.94 2.93l1.8-5.4C14.7.75 13.43 0 12 0 9.24 0 7 2.24 7 5h2c0-1.66 1.34-3 3-3s3 1.34 3 3c0 .83-.34 1.58-.88 2.12l-1.75 5.25C15.63 15.66 18 13.3 18 10V8.5h1zm-7 10c0-1.93-1.57-3.5-3.5-3.5S5 16.57 5 18.5c0 1.83 1.37 3.34 3.16 3.48l-1.8-5.41c-2.4.6-4.36 2.56-4.96 4.96L.68 21.3c-.14 1.79 1.21 3.25 3.06 3.37 1.86.12 3.53-1.15 3.94-2.93l1.8 5.4c.81-1.28 2.08-2.25 3.58-2.5 2.76-.46 5-1.76 5-4.5z"/></svg>
  ), },
  { id: 'Сабзавот', name: 'Сабзавот', name_tj: 'Сабзавот', water: 'Varies', icon: (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 mb-2 text-orange-500" viewBox="0 0 24 24" fill="currentColor"><path d="M2.2,8.6C2,8.1,2,7.6,2.3,7.1C2.5,6.6,2.9,6.2,3.4,6.1c0.5,0,1,0.2,1.3,0.5c0.4,0.3,0.6,0.8,0.7,1.3c0,0.5,0,1-0.2,1.5 c-0.2,0.5-0.6,0.8-1.1,1C3.6,10.4,3,10.2,2.6,9.8C2.3,9.4,2.1,8.9,2.2,8.6z M10.8,5.8c-0.1-0.5-0.3-1-0.6-1.4C9.8,4,9.3,3.7,8.8,3.6 c-0.5,0-1,0.2-1.4,0.5C7,4.5,6.7,5,6.6,5.5c-0.1,0.5,0,1,0.2,1.5C7,7.5,7.4,7.8,7.9,8c0.5,0.1,1-0.1,1.5-0.3c0.5-0.2,0.9-0.6,1.1-1.1 C10.8,6.2,10.8,6,10.8,5.8z M19.5,12.5c-0.5-0.1-1-0.1-1.5,0.1c-0.5,0.2-0.9,0.5-1.2,1c-0.3,0.5-0.5,1-0.4,1.6 c0.1,0.5,0.3,1,0.7,1.4c0.4,0.4,0.9,0.6,1.5,0.7c0.5,0.1,1,0,1.5-0.2c0.5-0.2,0.9-0.6,1.2-1.1c0.3-0.5,0.4-1.1,0.3-1.6 C21.1,13.8,20.4,12.9,19.5,12.5z M16.7,21.6c0.5,0,1-0.2,1.4-0.5c0.4-0.3,0.7-0.8,0.8-1.3c0.1-0.5,0-1.1-0.2-1.5 c-0.2-0.5-0.6-0.9-1.1-1.1c-0.5-0.2-1-0.2-1.5,0c-0.5,0.2-0.9,0.5-1.2,1c-0.3,0.5-0.4,1.1-0.3,1.6c0.1,0.5,0.4,1,0.8,1.4 C15.7,21.4,16.2,21.6,16.7,21.6z M12,1c-3.9,0-7,3.1-7,7c0,3.9,3.1,7,7,7s7-3.1,7-7C19,4.1,15.9,1,12,1z M12,13c-2.8,0-5-2.2-5-5s2.2-5,5-5 s5,2.2,5,5S14.8,13,12,13z"/></svg>
  ), },
  { id: 'Полезӣ', name: 'Полезӣ', name_tj: 'Полезӣ', water: 'Varies', icon: (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 mb-2 text-red-600" viewBox="0 0 24 24" fill="currentColor"><path d="M22 12c0 5.523-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2s10 4.477 10 10zm-3.529-5.232a.75.75 0 1 0-1.058-1.058l-5.657 5.657a.75.75 0 0 0 0 1.058l5.657 5.657a.75.75 0 1 0 1.058-1.058L13.586 12l4.885-4.232z"/></svg>
  ), },
  { id: 'Киштзори назди работ', name: 'Киштзори назди работ', name_tj: 'Киштзори назди работ', water: 'Varies', icon: (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 mb-2 text-green-700" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L1 12h3v8h14v-8h3L12 2zm3 16H9v-5H5l7-7 7 7h-4v5z"/></svg>
  ), },
];


const formSchema = z.object({
  cropType: z.string({ required_error: 'Намуди зироат бояд интихоб карда шавад.' }),
  plantingDate: z.date({ required_error: 'Санаи кишт бояд интихоб карда шавад.' }),
  fieldSize: z.coerce.number().min(0.1, 'Масоҳати кишт бояд аз 0 калон бошад.'),
  region: z.string().min(1, 'Минтақаи иқлимӣ бояд интихоб карда шавад.'),
  irrigationMethod: z.string().min(1, 'Усули обёрӣ бояд интихоб карда шавад.'),
});

type FormValues = z.infer<typeof formSchema>;

export function AiRecommendationForm() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WaterDistributionOutput | null>(null);
  const [selectedCrop, setSelectedCrop] = useState<string>('Пшеница');

  const { t, locale } = useLanguage();
  const { toast } = useToast();
  const { user } = useUser();
  const firestore = useFirestore();
  const { addCrop } = useCrop();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fieldSize: 10,
      plantingDate: new Date(),
      cropType: 'Пшеница',
      region: 'Рудакӣ (НГМ- III)',
      irrigationMethod: 'Бороздковое (Furrow)'
    },
  });

  const handleCropSelection = (cropId: string) => {
    setSelectedCrop(cropId);
    form.setValue('cropType', cropId);
  }

  async function onSubmit(values: FormValues) {
    setLoading(true);
    setResult(null);

    const input: WaterDistributionInput = {
      ...values,
      plantingDate: format(values.plantingDate, 'yyyy-MM-dd'),
    };

    try {
      const plan = await generateWaterDistributionPlan(input);
      setResult(plan);

      // Add the new crop to the dashboard
      const cropDetails = crops.find(c => c.id === values.cropType);
      if (cropDetails) {
        const newCrop = {
          id: Date.now(), // Use a simple timestamp for a unique ID
          name: cropDetails.name,
          name_tj: cropDetails.name_tj,
          area: values.fieldSize,
          stage: 'Нашъунамо', // A default stage
          stage_tj: 'Нашъунамо',
          image: placeholderImages.placeholderImages.find(p => p.id === `crop-${cropDetails.id.toLowerCase()}`)?.imageUrl,
          imageHint: `${cropDetails.id.toLowerCase()} field`,
          irrigationNotes: 'Тавсияҳои муфассалро дар асоси нақшаи тавлидшуда риоя кунед.',
          irrigationNotes_tj: 'Тавсияҳои муфассалро дар асоси нақшаи тавлидшуда риоя кунед.'
        };
        addCrop(newCrop);
      }

      toast({
        title: t('recommendations.planSaved'),
        description: t('recommendations.planSavedDesc'),
      });

    } catch (error: any) {
      console.error(error);
      const errorMessage = error.message || '';
      if (errorMessage.includes('503') || errorMessage.toLowerCase().includes('overloaded')) {
          toast({
              variant: "destructive",
              title: "Хидмат муваққатан дастнорас аст",
              description: "Модели зеҳни сунъӣ дар ҳоли ҳозир сербор аст. Лутфан, пас аз чанд лаҳза бори дигар кӯшиш кунед."
          });
      } else {
          toast({
              variant: "destructive",
              title: t('recommendations.errorGenerate'),
          });
      }
    } finally {
      setLoading(false);
    }
  }

  const getCalendarForSchedule = (startDate: Date, schedule: string) => {
    const days = [];
    let interval = 7; // default
    if (schedule.includes('5')) interval = 5;
    if (schedule.includes('10')) interval = 10;
    if (schedule.includes('14')) interval = 14;

    for (let i = 0; i < 5; i++) { // show next 5 irrigation dates
      days.push(addDays(startDate, i * interval));
    }
    return days;
  };
  
  const irrigationDates = useMemo(() => {
    if (result && form.watch('plantingDate')) {
      return getCalendarForSchedule(form.watch('plantingDate'), result.schedule);
    }
    return [];
  }, [result, form.watch('plantingDate')]);


  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('recommendations.title')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label>{t('recommendations.selectCrop')}</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mt-2">
                    {crops.map(crop => (
                      <Card
                        key={crop.id}
                        onClick={() => handleCropSelection(crop.id)}
                        className={cn(
                          "p-4 flex flex-col items-center justify-center cursor-pointer transition-all",
                          selectedCrop === crop.id ? 'border-primary ring-2 ring-primary' : 'hover:border-primary/50'
                        )}
                      >
                        {crop.icon}
                        <p className="text-sm font-medium text-center">{locale === 'tj' ? crop.name_tj : crop.name}</p>
                        <p className="text-xs text-muted-foreground">{crop.water}</p>
                      </Card>
                    ))}
                  </div>
                </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="plantingDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>{t('recommendations.startDate')}</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full justify-start text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                  )}
                                >
                                  <CalendarIcon className="mr-2 h-4 w-4" />
                                  {field.value ? format(field.value, "PPP") : <span>{t('recommendations.pickDate')}</span>}
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="fieldSize"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('recommendations.fieldArea')}</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder={t('recommendations.fieldAreaPlaceholder')} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="region"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('recommendations.climateZone')}</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('recommendations.selectClimateZone')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Рудакӣ (НГМ- III)">Рудакӣ (НГМ- III)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="irrigationMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('recommendations.irrigationMethod')}</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('recommendations.selectIrrigationMethod')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                               <SelectItem value="Бороздковое (Furrow)">{t('recommendations.furrow')}</SelectItem>
                              <SelectItem value="Дождевание (Sprinkler)">{t('recommendations.sprinkler')}</SelectItem>
                              <SelectItem value="Капельное (Drip)">{t('recommendations.drip')}</SelectItem>
                              <SelectItem value="Подпочвенное (Subsurface Drip)">{t('recommendations.subsurface')}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                 </div>

                 <Button type="submit" disabled={loading} size="lg" className="w-full">
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <BarChart className="mr-2 h-4 w-4" />}
                  {t('recommendations.calculateButton')}
                </Button>
              </CardContent>
            </Card>
          </form>
        </Form>
      </div>

      <div className="space-y-6">
        {result && (
          <Card className="bg-secondary/50">
            <CardHeader>
              <CardTitle>{t('recommendations.resultTitle')}</CardTitle>
              <CardDescription>{t('recommendations.resultDesc')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-baseline justify-between p-4 bg-background rounded-lg">
                <p className="text-sm text-muted-foreground">{t('recommendations.waterAmount')}</p>
                <p className="text-2xl font-bold text-primary">{result.waterAmount} <span className="text-sm font-normal">{t('recommendations.waterAmountUnit')}</span></p>
              </div>
              <div className="flex items-baseline justify-between p-4 bg-background rounded-lg">
                <p className="text-sm text-muted-foreground">{t('recommendations.schedule')}</p>
                <p className="text-lg font-semibold">{result.schedule}</p>
              </div>
              <div className="p-4 bg-background rounded-lg space-y-2">
                 <p className="text-sm text-muted-foreground">{t('recommendations.notes')}</p>
                 <p className="text-sm">{result.notes}</p>
              </div>
               <div className="p-4 bg-background rounded-lg space-y-2">
                <Label>{t('recommendations.calendar')}</Label>
                <Calendar
                  mode="multiple"
                  selected={irrigationDates}
                  defaultMonth={irrigationDates[0]}
                  className="rounded-md p-0"
                />
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
