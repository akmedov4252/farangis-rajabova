'use client';

import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { FileClock, PlusCircle, Trash2, Calculator } from 'lucide-react';
import { Separator } from './ui/separator';
import { useState, useMemo } from 'react';
import { irrigationRegime, waterModules, giosData, A_coeff } from '@/lib/water-plan-data';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { ChartContainer, ChartTooltipContent, ChartLegend, ChartLegendContent } from '@/components/ui/chart';


const cropSchema = z.object({
  name: z.string().min(1, 'Название обязательно'),
  area: z.coerce.number().min(0, 'Площадь должна быть положительной'),
});

const formSchema = z.object({
  gioName: z.string().min(1, 'Название ГИО обязательно'),
  totalArea: z.coerce.number().min(0, 'Общая площадь должна быть положительной'),
  crops: z.array(cropSchema).min(1, 'Требуется как минимум одна культура'),
  hydromoduleZone: z.string().min(1, 'Зона обязательна'),
  lambda: z.coerce.number().min(0, 'λ должна быть положительной'),
  canalPermeability: z.enum(['суст', 'миёна', 'зиёд']),
  canalLength: z.coerce.number().min(0, 'Длина должна быть положительной'),
  m: z.coerce.number().min(0, 'm должно быть положительным'),
});

type FormValues = z.infer<typeof formSchema>;

const months = ["Апрел", "Май", "Июн", "Июл", "Август", "Сентиябр", "Октябр"];
const decades = ["I", "II", "III"];

const chartColors = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))", "hsl(var(--chart-5))"];


// Main results display component
function ResultsDisplay({ results }: { results: CalculationResults | null }) {
    if (!results) {
        return null;
    }

    const { monthlyGrossVolumeData, cropDistributionData, netVsLossData, chartConfig } = useMemo(() => {
        if (!results) {
            return { monthlyGrossVolumeData: [], cropDistributionData: [], netVsLossData: [], chartConfig: {} };
        }

        const monthlyTotals = months.map(month => {
            const decadeVolumes = decades.map(decade => results.summary.totalW[month]?.[decade] || 0);
            return {
                month,
                volume: decadeVolumes.reduce((acc, v) => acc + v, 0)
            };
        });

        const cropDistribution = Object.entries(results.tables).map(([cropName, cropData], index) => ({
            name: cropName,
            value: cropData?.totalW || 0,
            fill: chartColors[index % chartColors.length]
        })).filter(item => item.value > 0);

        const netVsLoss = months.map(month => {
            const net = decades.reduce((sum, decade) => sum + (results.summary.totalQx[month]?.[decade] || 0), 0);
            const loss = decades.reduce((sum, decade) => sum + (results.summary.waterLoss[month]?.[decade] || 0), 0);
            return { month, net, loss };
        });

        const config = {
            volume: { label: "Объем (тыс. м³)", color: "hsl(var(--chart-1))" },
            net: { label: "Расход нетто (л/с)", color: "hsl(var(--chart-1))" },
            loss: { label: "Потери (л/с)", color: "hsl(var(--chart-2))" },
            ...cropDistribution.reduce((acc, item) => {
                acc[item.name] = { label: item.name, color: item.fill };
                return acc;
            }, {} as any)
        };

        return { 
            monthlyGrossVolumeData: monthlyTotals, 
            cropDistributionData: cropDistribution,
            netVsLossData: netVsLoss,
            chartConfig: config
        };
    }, [results]);

    return (
        <Card className="mt-8">
            <CardHeader>
                <CardTitle>Результаты расчета: План водопользования</CardTitle>
                <CardDescription>
                    Автоматически сгенерированный план на основе введенных данных для {results.gioName}.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
                 <Accordion type="multiple" defaultValue={['visuals']} className="w-full">
                    <AccordionItem value="visuals">
                        <AccordionTrigger className="font-semibold text-xl text-primary hover:no-underline">
                            Визуализация результатов
                        </AccordionTrigger>
                        <AccordionContent className="pt-4 grid grid-cols-1 xl:grid-cols-2 gap-8">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Сарфи умумии об (брутто) дар як моҳ</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ChartContainer config={chartConfig} className="h-[300px] w-full">
                                        <BarChart data={monthlyGrossVolumeData} margin={{ top: 20, right: 20, left: -10, bottom: 5 }}>
                                            <CartesianGrid vertical={false} />
                                            <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                                            <YAxis tickFormatter={(val) => `${(val / 1000).toFixed(0)}k`} />
                                            <Tooltip cursor={{ fill: 'hsl(var(--muted))' }} content={<ChartTooltipContent />} />
                                            <Bar dataKey="volume" fill="var(--color-volume)" radius={4} />
                                        </BarChart>
                                    </ChartContainer>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader>
                                    <CardTitle>Тақсимоти об аз рӯи намуди зироат</CardTitle>
                                </CardHeader>
                                <CardContent  className="flex items-center justify-center">
                                    <ChartContainer config={chartConfig} className="h-[300px] w-full">
                                        <PieChart>
                                            <Tooltip content={<ChartTooltipContent nameKey="name" />} />
                                            <Pie data={cropDistributionData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} labelLine={false} label={({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }) => {
                                                const RADIAN = Math.PI / 180;
                                                const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                                                const x = cx + radius * Math.cos(-midAngle * RADIAN);
                                                const y = cy + radius * Math.sin(-midAngle * RADIAN);
                                                return ( <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central"> {`${(percent * 100).toFixed(0)}%`} </text> );
                                            }}>
                                                {cropDistributionData.map((entry, index) => (
                                                  <Cell key={`cell-${index}`} fill={entry.fill} />
                                                ))}
                                            </Pie>
                                            <Legend content={<ChartLegendContent nameKey="name" />} />
                                        </PieChart>
                                    </ChartContainer>
                                </CardContent>
                            </Card>
                             <Card className="xl:col-span-2">
                                <CardHeader>
                                    <CardTitle>Талаботи холис ва талафоти об</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <ChartContainer config={chartConfig} className="h-[300px] w-full">
                                        <BarChart data={netVsLossData} margin={{ top: 20, right: 20, left: -10, bottom: 5 }}>
                                            <CartesianGrid vertical={false} />
                                            <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                                            <YAxis label={{ value: 'л/с', angle: -90, position: 'insideLeft' }} />
                                            <Tooltip cursor={{ fill: 'hsl(var(--muted))' }} content={<ChartTooltipContent />} />
                                            <Legend />
                                            <Bar dataKey="net" stackId="a" fill="var(--color-net)" name="Расход нетто" radius={[0, 0, 4, 4]} />
                                            <Bar dataKey="loss" stackId="a" fill="var(--color-loss)" name="Потери" radius={[4, 4, 0, 0]} />
                                        </BarChart>
                                    </ChartContainer>
                                </CardContent>
                            </Card>
                        </AccordionContent>
                    </AccordionItem>
                </Accordion>
                {Object.keys(results.tables).map(cropName => {
                    const cropResults = results.tables[cropName as keyof typeof results.tables];
                    if (!cropResults) return null;

                    return (
                        <div key={cropName}>
                            <h3 className="font-bold text-lg mb-2">План для культуры: {cropName} (Майдон: {cropResults.area.toFixed(2)} га)</h3>
                            <div className="overflow-x-auto">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Показатель</TableHead>
                                            {months.map(month => (
                                                <TableHead key={month} colSpan={3} className="text-center border-l">{month}</TableHead>
                                            ))}
                                            <TableHead className="text-center border-l">Итого</TableHead>
                                        </TableRow>
                                        <TableRow>
                                            <TableHead></TableHead>
                                            {months.flatMap(month => decades.map(decade => (
                                                <TableHead key={`${month}-${decade}`} className="text-center border-l w-[80px]">{decade}</TableHead>
                                            )))}
                                             <TableHead></TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        <TableRow>
                                            <TableCell>К (Модуль обмонии)</TableCell>
                                            {months.flatMap(month => decades.map(decade => (
                                                <TableCell key={`k-${month}-${decade}`} className="text-center border-l">{cropResults.K[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                            )))}
                                             <TableCell></TableCell>
                                        </TableRow>
                                        <TableRow>
                                            <TableCell>Sд (Площадь полива, га)</TableCell>
                                            {months.flatMap(month => decades.map(decade => (
                                                <TableCell key={`sd-${month}-${decade}`} className="text-center border-l">{cropResults.Sd[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                            )))}
                                            <TableCell className="text-center border-l font-bold">{cropResults.totalSd.toFixed(2)}</TableCell>
                                        </TableRow>
                                         <TableRow>
                                            <TableCell>qд (Гидромодуль, л/с*га)</TableCell>
                                            {months.flatMap(month => decades.map(decade => (
                                                <TableCell key={`qd-${month}-${decade}`} className="text-center border-l">{cropResults.qd[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                            )))}
                                            <TableCell></TableCell>
                                        </TableRow>
                                        <TableRow>
                                            <TableCell>Qx (Расход, л/с)</TableCell>
                                            {months.flatMap(month => decades.map(decade => (
                                                <TableCell key={`qx-${month}-${decade}`} className="text-center border-l">{cropResults.Qx[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                            )))}
                                            <TableCell></TableCell>
                                        </TableRow>
                                        <TableRow>
                                            <TableCell>W (Объем, тыс. м³)</TableCell>
                                            {months.flatMap(month => decades.map(decade => (
                                                <TableCell key={`w-${month}-${decade}`} className="text-center border-l">{cropResults.W[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                            )))}
                                            <TableCell className="text-center border-l font-bold">{cropResults.totalW.toFixed(2)}</TableCell>
                                        </TableRow>
                                    </TableBody>
                                </Table>
                            </div>
                        </div>
                    )
                })}
                 <Separator />
                <h3 className="font-bold text-lg">Сводный план для {results.gioName}</h3>
                 <div className="overflow-x-auto">
                    <Table>
                         <TableHeader>
                            <TableRow>
                                <TableHead>Показатель</TableHead>
                                {months.map(month => (
                                    <TableHead key={month} colSpan={3} className="text-center border-l">{month}</TableHead>
                                ))}
                                <TableHead className="text-center border-l">Итого</TableHead>
                            </TableRow>
                            <TableRow>
                                <TableHead></TableHead>
                                {months.flatMap(month => decades.map(decade => (
                                    <TableHead key={`${month}-${decade}`} className="text-center border-l w-[80px]">{decade}</TableHead>
                                )))}
                                <TableCell></TableCell>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            <TableRow>
                                <TableCell>Общая площадь полива (га)</TableCell>
                                {months.flatMap(month => decades.map(decade => (
                                    <TableCell key={`total-sd-${month}-${decade}`} className="text-center border-l font-semibold">{results.summary.totalSd[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                )))}
                                <TableCell className="text-center border-l font-bold">{results.summary.grandTotalSd.toFixed(2)}</TableCell>
                            </TableRow>
                            <TableRow>
                                <TableCell>Расход нетто (Qхолис, л/с)</TableCell>
                                {months.flatMap(month => decades.map(decade => (
                                    <TableCell key={`total-qx-${month}-${decade}`} className="text-center border-l font-semibold">{results.summary.totalQx[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                )))}
                                <TableCell></TableCell>
                            </TableRow>
                             <TableRow>
                                <TableCell>Потери в канале (S, л/с)</TableCell>
                                {months.flatMap(month => decades.map(decade => (
                                    <TableCell key={`loss-${month}-${decade}`} className="text-center border-l text-red-500">{results.summary.waterLoss[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                )))}
                                <TableCell></TableCell>
                            </TableRow>
                             <TableRow>
                                <TableCell>Расход брутто (Qғх, л/с)</TableCell>
                                {months.flatMap(month => decades.map(decade => (
                                    <TableCell key={`gross-qx-${month}-${decade}`} className="text-center border-l font-bold">{results.summary.grossQx[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                )))}
                                <TableCell></TableCell>
                            </TableRow>
                            <TableRow>
                                <TableCell>Объем брутто (W, тыс. м³)</TableCell>
                                {months.flatMap(month => decades.map(decade => (
                                    <TableCell key={`total-w-${month}-${decade}`} className="text-center border-l font-bold">{results.summary.totalW[month]?.[decade]?.toFixed(2) || '–'}</TableCell>
                                )))}
                                <TableCell className="text-center border-l font-bold">{results.summary.grandTotalW.toFixed(2)}</TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                 </div>
            </CardContent>
        </Card>
    );
}


type MonthlyData = { [decade: string]: number | undefined };
type CropResult = {
    area: number;
    K: { [month: string]: MonthlyData };
    Sd: { [month: string]: MonthlyData };
    qd: { [month: string]: MonthlyData };
    Qx: { [month: string]: MonthlyData };
    W: { [month: string]: MonthlyData };
    totalSd: number;
    totalW: number;
};
type CalculationResults = {
    gioName: string;
    tables: {
        [cropName: string]: CropResult | undefined;
    },
    summary: {
        totalSd: { [month: string]: MonthlyData };
        totalQx: { [month: string]: MonthlyData };
        waterLoss: { [month: string]: MonthlyData };
        grossQx: { [month: string]: MonthlyData };
        totalW: { [month: string]: MonthlyData };
        grandTotalSd: number;
        grandTotalW: number;
    }
};


export function WaterUsePlannerForm() {
  const [results, setResults] = useState<CalculationResults | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      gioName: 'АИО “Обшорон”',
      totalArea: 694.52,
      crops: giosData['АИО “Обшорон”'].crops,
      hydromoduleZone: 'III',
      lambda: 41.6,
      canalPermeability: 'миёна',
      m: 0.50,
      canalLength: 3.420,
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'crops',
  });

  const handleGIOChange = (gioName: string) => {
    const data = giosData[gioName as keyof typeof giosData];
    if (data) {
        form.setValue('totalArea', data.totalArea);
        form.setValue('crops', data.crops);
        form.setValue('lambda', data.lambda);
        form.setValue('canalPermeability', data.permeability);
        form.setValue('canalLength', data.length / 1000);
    }
  }

  const onSubmit = (data: FormValues) => {
     // 1. Initialize structures
    const cropResults: { [cropName: string]: CropResult } = {};
    const summary = {
        totalSd: {} as { [month: string]: MonthlyData },
        totalQx: {} as { [month: string]: MonthlyData },
        waterLoss: {} as { [month: string]: MonthlyData },
        grossQx: {} as { [month: string]: MonthlyData },
        totalW: {} as { [month: string]: MonthlyData },
        grandTotalSd: 0,
        grandTotalW: 0
    };

    const A = A_coeff[data.canalPermeability];

    // 2. Loop through each crop in the form
    data.crops.forEach(crop => {
        const cropArea = crop.area;
        const cropName = crop.name;
        const cropRegime = irrigationRegime[cropName as keyof typeof irrigationRegime];
        const cropModules = waterModules[cropName as keyof typeof waterModules];

        if (!cropRegime || !cropModules) {
            console.warn(`No data for crop: ${cropName}`);
            return;
        }

        const currentCropResult: CropResult = {
            area: cropArea,
            K: {}, Sd: {}, qd: {}, Qx: {}, W: {},
            totalSd: 0, totalW: 0
        };

        // 3. Loop through months and decades
        months.forEach(month => {
            currentCropResult.K[month] = {};
            currentCropResult.Sd[month] = {};
            currentCropResult.qd[month] = {};
            currentCropResult.Qx[month] = {};
            currentCropResult.W[month] = {};

            decades.forEach(decade => {
                const decadeIndex = decades.indexOf(decade);
                const T = (month === "Феврал" && decadeIndex === 2) ? 8 : 10; // Simple leap year ignore

                // Calculate K_d
                const K_d = cropModules[month]?.[decade] || 0;
                currentCropResult.K[month]![decade] = K_d;

                // Calculate S_d
                const S_d = cropArea * K_d;
                currentCropResult.Sd[month]![decade] = S_d;
                currentCropResult.totalSd += S_d;

                // Calculate q_d
                const regimeForDecade = cropRegime.find(r => r.decade === decade && r.month === month);
                let q_d = 0;
                if (regimeForDecade) {
                    if (regimeForDecade.q1 && regimeForDecade.t1 && regimeForDecade.q2 && regimeForDecade.t2) {
                        q_d = (regimeForDecade.q1 * regimeForDecade.t1 + regimeForDecade.q2 * regimeForDecade.t2) / T;
                    } else if (regimeForDecade.q0 && regimeForDecade.t0) {
                        q_d = (regimeForDecade.q0 * regimeForDecade.t0) / T;
                    } else if (regimeForDecade.q_equal) {
                        q_d = regimeForDecade.q_equal;
                    }
                }
                currentCropResult.qd[month]![decade] = q_d;

                // Calculate Qx
                const Qx = S_d * q_d;
                currentCropResult.Qx[month]![decade] = Qx;

                // Calculate W
                const W = (86.4 * T * Qx) / 1000;
                currentCropResult.W[month]![decade] = W;
                currentCropResult.totalW += W;
                
                // Aggregate into summary
                if (!summary.totalSd[month]) summary.totalSd[month] = {};
                summary.totalSd[month]![decade] = (summary.totalSd[month]![decade] || 0) + S_d;
                if (!summary.totalQx[month]) summary.totalQx[month] = {};
                summary.totalQx[month]![decade] = (summary.totalQx[month]![decade] || 0) + Qx;

            });
        });
        cropResults[cropName] = currentCropResult;
    });

    // 4. Calculate final summary row
    months.forEach(month => {
        summary.waterLoss[month] = {};
        summary.grossQx[month] = {};
        summary.totalW[month] = {};

        decades.forEach(decade => {
            const T = 10;
            const Qx_total = summary.totalQx[month]?.[decade] || 0;

            // S=2,1*10-3*A* λ*ωнг* Qх 0,5  (ωнг is assumed 1 for now)
            // Simplified formula based on docs: S = A * L * sqrt(Q) -- unclear which one to use. Let's use the complex one
            // S = 0.0021 * A * λ * 1 * sqrt(Qx_total)
            const waterLoss = 0.0021 * A * data.lambda * Math.sqrt(Qx_total);
            summary.waterLoss[month]![decade] = waterLoss;
            
            const grossQx = Qx_total + waterLoss;
            summary.grossQx[month]![decade] = grossQx;

            const totalW = (86.4 * T * grossQx) / 1000;
            summary.totalW[month]![decade] = totalW;
            
            summary.grandTotalSd += summary.totalSd[month]?.[decade] || 0;
            summary.grandTotalW += totalW;
        });
    });


    setResults({
        gioName: data.gioName,
        tables: cropResults,
        summary,
    });
  };

  return (
    <div className="max-w-6xl mx-auto flex flex-col gap-8">
      <div className="flex items-center gap-4 mb-4">
        <FileClock className="w-8 h-8 text-muted-foreground" />
        <h1 className="font-headline text-3xl font-semibold">Планировщик водопользования (Нақшаи истифодабарии об)</h1>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Исходные данные</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="multiple" defaultValue={['item-1']} className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="font-semibold text-lg">Сельскохозяйственные площади</AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField control={form.control} name="gioName" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Название ГИО</FormLabel>
                                <Select onValueChange={(value) => {field.onChange(value); handleGIOChange(value); }} defaultValue={field.value}>
                                    <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                                    <SelectContent>
                                        <SelectItem value="ГИО-1">ГИО-1</SelectItem>
                                        <SelectItem value="ГИО-2">ГИО-2</SelectItem>
                                        <SelectItem value="ГИО-3">ГИО-3</SelectItem>
                                        <SelectItem value="ГИО-4">ГИО-4</SelectItem>
                                        <SelectItem value="АИО “Обшорон”">АИО “Обшорон” (Итого)</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="totalArea" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Общая площадь ГИО (га)</FormLabel>
                                <FormControl><Input type="number" {...field} readOnly /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                    <Separator />
                     <h4 className="font-medium text-center">Культуры и их площади (по данным Таблицы 1)</h4>
                     <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                        {fields.map((field, index) => (
                           <div key={field.id} className="grid grid-cols-[1fr_1fr_auto] gap-4 items-end p-4 border rounded-lg">
                             <FormField control={form.control} name={`crops.${index}.name`} render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Название культуры</FormLabel>
                                     <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <FormControl>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Выберите культуру" />
                                        </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            {Object.keys(irrigationRegime).map(cropName => (
                                                <SelectItem key={cropName} value={cropName}>{cropName}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                             )} />
                             <FormField control={form.control} name={`crops.${index}.area`} render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Площадь (га)</FormLabel>
                                    <FormControl><Input type="number" {...field} /></FormControl>
                                    <FormMessage />
                                </FormItem>
                             )} />
                             <Button type="button" variant="ghost" size="icon" onClick={() => remove(index)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                           </div>
                        ))}
                     </div>
                     <Button type="button" variant="outline" onClick={() => append({ name: 'Гандум', area: 0 })}>
                        <PlusCircle className="mr-2 h-4 w-4" /> Добавить культуру
                    </Button>

                  </AccordionContent>
                </AccordionItem>

                 <AccordionItem value="item-2">
                  <AccordionTrigger className="font-semibold text-lg">Гидромодульная зона и технические показатели канала</AccordionTrigger>
                  <AccordionContent className="pt-4 grid grid-cols-2 md:grid-cols-3 gap-6">
                     <FormField control={form.control} name="hydromoduleZone" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Гидромодульная зона</FormLabel>
                             <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                                <SelectContent>
                                    <SelectItem value="I">Зона I</SelectItem>
                                    <SelectItem value="II">Зона II</SelectItem>
                                    <SelectItem value="III">Зона III (Центральный Таджикистан)</SelectItem>
                                    <SelectItem value="IV">Зона IV</SelectItem>
                                    <SelectItem value="Рудакӣ (НГМ- III)">Рудакӣ (НГМ- III)</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                     )} />
                      <FormField control={form.control} name="canalLength" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Длина канала (км)</FormLabel>
                            <FormControl><Input type="number" step="0.001" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                     <FormField control={form.control} name="lambda" render={({ field }) => (
                        <FormItem>
                            <FormLabel>λ (Зариби хоси дарозии)</FormLabel>
                            <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                     <FormField control={form.control} name="canalPermeability" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Проницаемость канала</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                                <SelectContent>
                                    <SelectItem value="суст">Суст (слабая)</SelectItem>
                                    <SelectItem value="миёна">Миёна (средняя)</SelectItem>
                                    <SelectItem value="зиёд">Зиёд (высокая)</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                     )} />
                     <FormField control={form.control} name="m" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Коэффициент m</FormLabel>
                            <FormControl><Input type="number" step="0.01" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
           <Button type="submit" size="lg" className="w-full">
            <Calculator className="mr-2 h-5 w-5" /> Рассчитать план водопользования
          </Button>
        </form>
      </Form>

      {results && <ResultsDisplay results={results} />}
    </div>
  );
}
