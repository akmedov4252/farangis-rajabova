'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Button } from './ui/button';
import { useFirestore, useUser } from '@/firebase';
import { addDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { collection } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { Calendar as CalendarIcon, Loader2 } from 'lucide-react';
import { Popover, PopoverTrigger, PopoverContent } from './ui/popover';
import { Calendar } from './ui/calendar';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { useLanguage } from '@/context/language-context';

const formSchema = z.object({
  region: z.string().min(1, "Бассейн обязателен."),
  directorate: z.string().min(1, "Управление обязательно."),
  association: z.string().min(1, "Ассоциация обязательна."),
  cropType: z.string().min(1),
  fieldSize: z.coerce.number().min(0),
  growthStage: z.string().min(1),
  calculationDate: z.date({ required_error: "Дата расчета обязательна." }),
});

type FormValues = z.infer<typeof formSchema>;

const cropData = {
  'Кукуруза': { duration: 120, coefficients: { 'Начальный рост': 0.4, 'Развитие': 0.8, 'Цветение': 1.2, 'Плодоношение': 1.15, 'Созревание': 0.6, 'Весь сезон': 0.85 } },
  'Соя': { duration: 110, coefficients: { 'Начальный рост': 0.4, 'Развитие': 0.8, 'Цветение': 1.15, 'Плодоношение': 1.05, 'Созревание': 0.5, 'Весь сезон': 0.8 } },
  'Пшеница': { duration: 130, coefficients: { 'Начальный рост': 0.3, 'Кущение': 0.7, 'Цветение': 1.15, 'Плодоношение': 1.1, 'Созревание': 0.3, 'Весь сезон': 0.75 } },
  'Хлопок': { duration: 150, coefficients: { 'Начальный рост': 0.35, 'Развитие': 0.75, 'Цветение': 1.15, 'Плодоношение': 1.2, 'Созревание': 0.7, 'Весь сезон': 0.85 } },
  'Овощи': { duration: 90, coefficients: { 'Начальный рост': 0.5, 'Развитие': 0.8, 'Цветение': 1.05, 'Плодоношение': 1.0, 'Созревание': 0.9, 'Весь сезон': 0.88 } },
};


const ETo = 5; // mm/day

export function CropWaterCalculator() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const firestore = useFirestore();
  const { user } = useUser();
  const { t } = useLanguage();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cropType: 'Хлопок',
      fieldSize: 100,
      growthStage: 'Весь сезон',
      region: 'Сырдарья',
      directorate: 'Управление 1',
      association: 'Ассоциация A',
      calculationDate: new Date(),
    },
    mode: 'onChange'
  });

  const watchedValues = form.watch();
  const { cropType, fieldSize, growthStage } = watchedValues;
    
  let dailyWaterNeedM3 = 0;
  let weeklyWaterNeedM3 = 0;
  let seasonalWaterNeedM3 = 0;
  if (cropType && growthStage && fieldSize >= 0) {
    const selectedCropData = cropData[cropType as keyof typeof cropData];
    const kc = selectedCropData.coefficients[growthStage as keyof typeof selectedCropData.coefficients];
    const seasonDuration = selectedCropData.duration;

    const ETc = kc * ETo; // Crop Evapotranspiration in mm/day
    const dailyWaterNeedLiters = ETc * fieldSize * 10; 
    dailyWaterNeedM3 = dailyWaterNeedLiters; // Result in m^3/day
    weeklyWaterNeedM3 = dailyWaterNeedM3 * 7;
    seasonalWaterNeedM3 = dailyWaterNeedM3 * seasonDuration;
  }
  
  const results = {
      daily: isNaN(dailyWaterNeedM3) ? 0 : dailyWaterNeedM3,
      weekly: isNaN(weeklyWaterNeedM3) ? 0 : weeklyWaterNeedM3,
      seasonal: isNaN(seasonalWaterNeedM3) ? 0 : seasonalWaterNeedM3,
  };

  const handleSave = () => {
    if (!user) {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: t('cropCalculator.saveError'),
      });
      return;
    }
    setLoading(true);

    const values = form.getValues();
    const analysisName = `${values.cropType} - ${values.region} - ${values.directorate} - ${values.association}`;

    const regionalAnalyticsData = {
      date: values.calculationDate.toISOString(),
      region: values.region,
      directorate: values.directorate,
      association: values.association,
      totalConsumption: results.weekly, // Saving weekly consumption as total
      averageLoss: 0, // Placeholder as this calculator doesn't calculate loss
      analysisName: analysisName,
      cropType: values.cropType,
      fieldSize: values.fieldSize,
    };
    
    const collectionRef = collection(firestore, 'regionalAnalytics');
    addDocumentNonBlocking(collectionRef, regionalAnalyticsData)
      .then(() => {
        toast({
          title: t('cropCalculator.saveSuccess'),
          description: t('cropCalculator.saveSuccessDesc'),
        });
      })
      .catch((err) => {
        console.error("Error saving to regional analytics: ", err);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
      <Form {...form}>
        <form className="space-y-6">
            <FormField
              control={form.control}
              name="region"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('cropCalculator.basin')}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder={t('cropCalculator.selectBasin')} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Сырдарья">{t('cropCalculator.syrdarya')}</SelectItem>
                      <SelectItem value="Амударья">{t('cropCalculator.amudarya')}</SelectItem>
                      <SelectItem value="Зарафшон">{t('cropCalculator.zarafshon')}</SelectItem>
                      <SelectItem value="Кофарнихон">{t('cropCalculator.kofarnihon')}</SelectItem>
                      <SelectItem value="Сурхоб">{t('cropCalculator.surkhob')}</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="directorate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('cropCalculator.directorate')}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder={t('cropCalculator.selectDirectorate')} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Управление 1">{t('cropCalculator.directorate1')}</SelectItem>
                      <SelectItem value="Управление 2">{t('cropCalculator.directorate2')}</SelectItem>
                      <SelectItem value="Управление 3">{t('cropCalculator.directorate3')}</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="association"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('cropCalculator.association')}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder={t('cropCalculator.selectAssociation')} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Ассоциация A">{t('cropCalculator.associationA')}</SelectItem>
                      <SelectItem value="Ассоциация B">{t('cropCalculator.associationB')}</SelectItem>
                      <SelectItem value="Ассоциация C">{t('cropCalculator.associationC')}</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="cropType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('cropCalculator.cropType')}</FormLabel>
                  <Select onValueChange={(value) => {
                      field.onChange(value);
                      form.setValue('growthStage', 'Весь сезон'); // Reset to a common stage
                  }} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder={t('cropCalculator.selectCrop')} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Кукуруза">{t('cropCalculator.corn')}</SelectItem>
                      <SelectItem value="Соя">{t('cropCalculator.soy')}</SelectItem>
                      <SelectItem value="Пшеница">{t('cropCalculator.wheat')}</SelectItem>
                      <SelectItem value="Хлопок">{t('cropCalculator.cotton')}</SelectItem>
                      <SelectItem value="Овощи">{t('cropCalculator.vegetables')}</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
            control={form.control}
            name="fieldSize"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t('cropCalculator.fieldArea')}</FormLabel>
                <FormControl>
                  <Input type="number" {...field} onChange={e => field.onChange(parseFloat(e.target.value))} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
              control={form.control}
              name="growthStage"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('cropCalculator.growthStage')}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder={t('cropCalculator.selectStage')} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Весь сезон">{t('cropCalculator.wholeSeason')}</SelectItem>
                      <Separator />
                      {cropType && Object.keys(cropData[cropType as keyof typeof cropData].coefficients).map(stage => {
                        if (stage === 'Весь сезон') return null;
                        return <SelectItem key={stage} value={stage}>{stage}</SelectItem>
                      })}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="calculationDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>{t('cropCalculator.calcDate')}</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {field.value ? format(field.value, "PPP") : <span>{t('recommendations.pickDate')}</span>}
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={(date) => {
                            if (date) field.onChange(date);
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
        </form>
      </Form>

      <div className="flex flex-col justify-between">
        <Card className="bg-secondary/50">
          <CardHeader>
            <CardTitle className="font-headline">{t('cropCalculator.resultTitle')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
              <div className="space-y-4">
                  <div className="flex justify-between items-baseline">
                      <p className="text-muted-foreground">{t('cropCalculator.dailyNeed')}</p>
                      <p className="text-2xl font-bold">{results.daily.toFixed(2)} <span className="text-base font-normal">{t('cropCalculator.dailyUnit')}</span></p>
                  </div>
                  <Separator />
                  <div className="flex justify-between items-baseline">
                      <p className="text-muted-foreground">{t('cropCalculator.weeklyNeed')}</p>
                      <p className="text-3xl font-bold text-primary">{results.weekly.toFixed(2)} <span className="text-base font-normal">{t('cropCalculator.weeklyUnit')}</span></p>
                  </div>
                   <Separator />
                  <div className="flex justify-between items-baseline">
                      <p className="text-muted-foreground">{t('cropCalculator.seasonalNeed')}</p>
                      <p className="text-3xl font-bold text-accent">{new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 }).format(results.seasonal)} <span className="text-base font-normal">{t('cropCalculator.seasonalUnit')}</span></p>
                  </div>
              </div>
              <div className="text-sm text-muted-foreground pt-4 border-t">
                  {t('cropCalculator.note')}
              </div>
          </CardContent>
        </Card>
        <Button onClick={form.handleSubmit(handleSave)} disabled={loading || !user} size="lg" className="w-full mt-4">
           {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
           {t('cropCalculator.saveButton')}
        </Button>
      </div>
    </div>
  );
}

    