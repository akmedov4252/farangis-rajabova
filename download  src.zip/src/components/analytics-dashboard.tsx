'use client';

import { useState, useMemo } from 'react';
import { DateRange } from "react-day-picker"
import { Bar, BarChart, CartesianGrid, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend, LineChart, Line } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AreaChart, Droplet, Globe, Filter, Building, FileText, Calendar as CalendarIcon, BarChart as BarChartIcon, TrendingUp } from 'lucide-react';
import { ChartContainer, ChartTooltipContent, ChartLegend, ChartLegendContent } from '@/components/ui/chart';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, limit } from 'firebase/firestore';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format, parseISO, isValid, startOfDay, endOfDay } from 'date-fns';
import { Skeleton } from './ui/skeleton';
import { WaterDistributionPlanner } from './water-distribution-planner';
import { Separator } from './ui/separator';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar } from './ui/calendar';
import { cn } from '@/lib/utils';

type AnalyticsDashboardProps = {
  t: (key: string, params?: Record<string, string | number>) => string;
}

export function AnalyticsDashboard({ t }: AnalyticsDashboardProps) {
  const firestore = useFirestore();
  const analyticsQuery = useMemoFirebase(
    () => firestore ? query(collection(firestore, 'regionalAnalytics'), orderBy('date', 'desc'), limit(100)) : null,
    [firestore]
  );
  const { data: allData, isLoading: isAnalyticsLoading } = useCollection<any>(analyticsQuery);

  const [selectedBasin, setSelectedBasin] = useState('all');
  const [selectedDirectorate, setSelectedDirectorate] = useState('all');
  const [selectedAssociation, setSelectedAssociation] = useState('all');
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  const [chartGroupBy, setChartGroupBy] = useState<GroupBy>('basin');


  const [activeFilters, setActiveFilters] = useState({
    basin: 'all',
    directorate: 'all',
    association: 'all',
    dateRange: undefined as DateRange | undefined,
  });

  const handleApplyFilters = () => {
    setActiveFilters({
      basin: selectedBasin,
      directorate: selectedDirectorate,
      association: selectedAssociation,
      dateRange: dateRange,
    });
  };

  const filteredData = useMemo(() => {
    if (!allData) return [];
    return allData.filter(item => {
      const basinMatch = activeFilters.basin === 'all' || item.region === activeFilters.basin;
      const directorateMatch = activeFilters.directorate === 'all' || item.directorate === activeFilters.directorate;
      const associationMatch = activeFilters.association === 'all' || item.association === activeFilters.association;
      
      let dateMatch = true;
      if (activeFilters.dateRange?.from) {
          try {
              const itemDate = parseISO(item.date);
              if (isValid(itemDate)) {
                  const from = startOfDay(activeFilters.dateRange.from);
                  const to = activeFilters.dateRange.to ? endOfDay(activeFilters.dateRange.to) : endOfDay(new Date());
                  dateMatch = itemDate >= from && itemDate <= to;
              } else {
                  dateMatch = false;
              }
          } catch {
              dateMatch = false;
          }
      }

      return basinMatch && directorateMatch && associationMatch && dateMatch;
    });
  }, [allData, activeFilters]);

  const {
    totalConsumption,
    topBasin,
    barChartData,
    cropWaterUsageData,
    timeSeriesData,
    chartConfig
  } = useMemo(() => {
    const basinMap = new Map<string, number>();
    const cropMap = new Map<string, number>();
    let total = 0;
    
    const timeSeriesMap = new Map<string, number>();

    filteredData.forEach(item => {
      total += item.totalConsumption;
      basinMap.set(item.region, (basinMap.get(item.region) || 0) + item.totalConsumption);
      if (item.cropType) {
        cropMap.set(item.cropType, (cropMap.get(item.cropType) || 0) + item.totalConsumption);
      }
       try {
        const dateKey = format(parseISO(item.date), 'yyyy-MM-dd');
        timeSeriesMap.set(dateKey, (timeSeriesMap.get(dateKey) || 0) + item.totalConsumption);
      } catch (e) {
        // Ignore invalid date formats
      }
    });
    
    const consumptionMap = new Map<string, number>();
    filteredData.forEach(item => {
      let key;
      if (chartGroupBy === 'basin') {
        key = item.region;
      } else if (chartGroupBy === 'directorate') {
        key = item.directorate;
      } else { // association
        key = item.association;
      }
      if (key) {
        consumptionMap.set(key, (consumptionMap.get(key) || 0) + item.totalConsumption);
      }
    });

    const findTop = (map: Map<string, number>) => {
        if (map.size === 0) return { name: t('analytics.noData'), consumption: 0 };
        const topEntry = [...map.entries()].reduce((a, b) => b[1] > a[1] ? b : a, ['', 0]);
        return { name: topEntry[0], consumption: topEntry[1]};
    }
    
    const topBasinResult = findTop(basinMap);
    
    const sortedTimeSeries = Array.from(timeSeriesMap.entries())
      .map(([date, consumption]) => ({ date, consumption }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    const config = {
      consumption: { label: t('analytics.consumption') + ` (${t('analytics.consumptionUnitShort')}/га)`, color: "hsl(var(--chart-1))" },
      directorate: { label: t('analytics.consumption') + ` (${t('analytics.consumptionUnitShort')}/га)`, color: "hsl(var(--chart-2))" },
      ...Array.from(cropMap.keys()).reduce((acc, cropName) => {
        acc[cropName] = { label: cropName, color: `hsl(var(--chart-${(Array.from(cropMap.keys()).indexOf(cropName) % 5) + 1}))` };
        return acc;
      }, {} as any)
    };

    return {
      totalConsumption: total,
      topBasin: topBasinResult,
      barChartData: Array.from(consumptionMap, ([name, consumption]) => ({ name, consumption })),
      cropWaterUsageData: Array.from(cropMap, ([name, value]) => ({ name, value, fill: `var(--color-${name})` })),
      timeSeriesData: sortedTimeSeries,
      chartConfig: config,
    };
  }, [filteredData, chartGroupBy, t]);
  
  type GroupBy = 'basin' | 'directorate' | 'association';

  const groupByTitle = {
    basin: t('analytics.byBasin'),
    directorate: t('analytics.byDirectorate'),
    association: t('analytics.byAssociation')
  };

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-2">
        <h1 className="font-headline text-3xl font-bold tracking-tight">{t('analytics.title')}</h1>
        <p className="text-muted-foreground">{t('analytics.description')}</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            {t('analytics.filters')}
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <Select value={selectedBasin} onValueChange={setSelectedBasin}>
            <SelectTrigger>
              <SelectValue placeholder={t('analytics.selectBasin')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('analytics.allBasins')}</SelectItem>
              <SelectItem value="Сырдарья">{t('analytics.syrdarya')}</SelectItem>
              <SelectItem value="Амударья">{t('analytics.amudarya')}</SelectItem>
              <SelectItem value="Зарафшон">{t('analytics.zarafshon')}</SelectItem>
              <SelectItem value="Кофарнихон">{t('analytics.kofarnihon')}</SelectItem>
              <SelectItem value="Сурхоб">{t('analytics.surkhob')}</SelectItem>
            </SelectContent>
          </Select>
           <Select value={selectedDirectorate} onValueChange={setSelectedDirectorate}>
            <SelectTrigger>
              <SelectValue placeholder={t('analytics.selectDirectorate')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('analytics.allDirectorates')}</SelectItem>
              <SelectItem value="Управление 1">{t('analytics.directorate1')}</SelectItem>
              <SelectItem value="Управление 2">{t('analytics.directorate2')}</SelectItem>
              <SelectItem value="Управление 3">{t('analytics.directorate3')}</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedAssociation} onValueChange={setSelectedAssociation}>
            <SelectTrigger>
              <SelectValue placeholder={t('analytics.selectAssociation')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('analytics.allAssociations')}</SelectItem>
              <SelectItem value="Ассоциация A">{t('analytics.associationA')}</SelectItem>
              <SelectItem value="Ассоциация B">{t('analytics.associationB')}</SelectItem>
              <SelectItem value="Ассоциация C">{t('analytics.associationC')}</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex flex-col gap-2">
            <Popover>
                <PopoverTrigger asChild>
                <Button
                    id="date"
                    variant={"outline"}
                    className={cn(
                    "w-full justify-start text-left font-normal",
                    !dateRange && "text-muted-foreground"
                    )}
                >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange?.from ? (
                    dateRange.to ? (
                        <>
                        {format(dateRange.from, "LLL dd, y")} -{" "}
                        {format(dateRange.to, "LLL dd, y")}
                        </>
                    ) : (
                        format(dateRange.from, "LLL dd, y")
                    )
                    ) : (
                    <span>{t('analytics.pickDate')}</span>
                    )}
                </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange?.from}
                    selected={dateRange}
                    onSelect={setDateRange}
                    numberOfMonths={2}
                />
                </PopoverContent>
            </Popover>
          </div>
          <Button onClick={handleApplyFilters} className="w-full lg:col-span-4">{t('analytics.apply')}</Button>
        </CardContent>
      </Card>

       <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.totalConsumption')}</CardTitle>
            <Droplet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalConsumption.toLocaleString(undefined, { maximumFractionDigits: 0 })} {t('analytics.totalConsumptionUnit')}</div>
            <p className="text-xs text-muted-foreground">{t('analytics.totalConsumptionDesc')}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t('analytics.topBasin')}</CardTitle>
            <Globe className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{topBasin.name || '-'}</div>
            <p className="text-xs text-muted-foreground">{topBasin.consumption > 0 ? t('analytics.topBasinDesc', {consumption: topBasin.consumption.toLocaleString(undefined, { maximumFractionDigits: 0 })}) : ''}</p>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>{t('analytics.recentRecords')}</CardTitle>
          <CardDescription>{t('analytics.recentRecordsDesc')}</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('analytics.basin')}</TableHead>
                <TableHead>{t('analytics.directorate')}</TableHead>
                <TableHead>{t('analytics.association')}</TableHead>
                <TableHead>{t('analytics.cropType')}</TableHead>
                <TableHead className="text-right">{t('analytics.weeklyConsumption')}</TableHead>
                <TableHead className="text-right">{t('analytics.recordDate')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isAnalyticsLoading && Array.from({ length: 3 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-5 w-20 ml-auto" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-5 w-32 ml-auto" /></TableCell>
                </TableRow>
              ))}
              {filteredData.length > 0 ? filteredData.slice(0, 10).map(item => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.region}</TableCell>
                  <TableCell>{item.directorate || '-'}</TableCell>
                  <TableCell>{item.association || '-'}</TableCell>
                  <TableCell>{item.cropType || '-'}</TableCell>
                  <TableCell className="text-right">{item.totalConsumption.toLocaleString(undefined, { maximumFractionDigits: 0 })}</TableCell>
                  <TableCell className="text-right">{isValid(parseISO(item.date)) ? format(parseISO(item.date), 'dd.MM.yyyy HH:mm') : '-'}</TableCell>
                </TableRow>
              )) : !isAnalyticsLoading && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">{t('analytics.noDataToDisplay')}</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>


      <div className="grid grid-cols-1 gap-8 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>{t('analytics.consumptionBy', {groupBy: groupByTitle[chartGroupBy]})}</CardTitle>
                <CardDescription>{t('analytics.consumptionByDesc')}</CardDescription>
              </div>
              <Select value={chartGroupBy} onValueChange={(value) => setChartGroupBy(value as GroupBy)}>
                  <SelectTrigger className="w-[180px]">
                    <BarChartIcon className="w-4 h-4 mr-2" />
                    <SelectValue placeholder={t('analytics.groupBy')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="basin">{t('analytics.byBasin')}</SelectItem>
                    <SelectItem value="directorate">{t('analytics.byDirectorate')}</SelectItem>
                    <SelectItem value="association">{t('analytics.byAssociation')}</SelectItem>
                  </SelectContent>
                </Select>
            </div>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-[300px] w-full">
              <BarChart data={barChartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="name" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
                <YAxis tickFormatter={(value) => `${(value / 1000)}k`} />
                <Tooltip cursor={{fill: 'hsl(var(--muted))'}} content={<ChartTooltipContent />} />
                <Bar dataKey="consumption" fill="var(--color-consumption)" radius={4} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
              <CardTitle>{t('analytics.usageByCrop')}</CardTitle>
              <CardDescription>{t('analytics.usageByCropDesc')}</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
              <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <PieChart>
                      <Tooltip content={<ChartTooltipContent nameKey="name" />} />
                      <Legend content={<ChartLegendContent nameKey="name"/>} />
                      <Pie data={cropWaterUsageData} dataKey="value" nameKey="name" innerRadius={60} outerRadius={90} paddingAngle={5} />
                  </PieChart>
              </ChartContainer>
          </CardContent>
        </Card>
      </div>

       <Card>
        <CardHeader>
          <CardTitle>{t('analytics.consumptionDynamics')}</CardTitle>
          <CardDescription>
            {t('analytics.consumptionDynamicsDesc')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[400px] w-full">
            <LineChart data={timeSeriesData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis 
                dataKey="date" 
                tickFormatter={(value) => format(new Date(value), 'dd.MM')}
                tickLine={false} 
                axisLine={false} 
                tickMargin={8}
              />
              <YAxis 
                tickFormatter={(value) => `${(value / 1000)}k ${t('analytics.consumptionUnitShort')}`}
                tickLine={false} 
                axisLine={false} 
                tickMargin={8}
              />
              <Tooltip 
                cursor={{ stroke: 'hsl(var(--muted))' }}
                content={
                  <ChartTooltipContent 
                    labelFormatter={(label) => {
                        const date = new Date(label);
                        return isValid(date) ? format(date, "PPP") : label;
                    }}
                    formatter={(value) => [`${(value as number).toLocaleString()} ${t('analytics.consumptionUnitShort')}`, t('analytics.consumption')]}
                  />}
              />
              <Line 
                type="monotone" 
                dataKey="consumption" 
                stroke="hsl(var(--chart-1))" 
                strokeWidth={2} 
                dot={{
                    r: 4,
                    fill: "hsl(var(--chart-1))",
                    stroke: "hsl(var(--background))",
                    strokeWidth: 2,
                }}
              />
            </LineChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );
}

    