"use client";

import { useLanguage, Locale } from "@/context/language-context";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export function LanguageSwitcher() {
  const { locale, setLocale, t } = useLanguage();

  const handleLanguageChange = (newLocale: Locale) => {
    setLocale(newLocale);
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      <div
        className={cn(
          "rounded-lg border-2 p-4 cursor-pointer",
          locale === "ru" ? "border-primary" : "border-transparent"
        )}
        onClick={() => handleLanguageChange("ru")}
      >
        <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">🇷🇺</span>
            <h4 className="font-semibold">Русский</h4>
        </div>
        <p className="text-sm text-muted-foreground">Изменить язык интерфейса на русский.</p>
      </div>
      <div
        className={cn(
          "rounded-lg border-2 p-4 cursor-pointer",
          locale === "tj" ? "border-primary" : "border-transparent"
        )}
        onClick={() => handleLanguageChange("tj")}
      >
        <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">🇹🇯</span>
            <h4 className="font-semibold">Тоҷикӣ</h4>
        </div>
        <p className="text-sm text-muted-foreground">Тағйир додани забони интерфейс ба тоҷикӣ.</p>
      </div>
    </div>
  );
}
