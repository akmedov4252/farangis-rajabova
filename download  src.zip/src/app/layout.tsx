import type { Metadata } from 'next';
import './globals.css';
import { Inter } from 'next/font/google';
import { Literata } from 'next/font/google';
import { Providers } from './providers';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});
const literata = Literata({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-literata',
});


export const metadata: Metadata = {
  title: 'Оби ман',
  description: 'Гибридное офлайн/онлайн приложение для фермеров и специалистов по орошению.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning className={`${inter.variable} ${literata.variable}`}>
      <body>
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
