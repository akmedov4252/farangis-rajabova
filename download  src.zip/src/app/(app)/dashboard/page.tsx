'use client';

import { useState, useMemo } from 'react';
import Image from 'next/image';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowRight, Leaf, TrendingUp, CalendarClock, Info, Waves, Droplet, Clock, X } from 'lucide-react';
import placeholderImages from '@/lib/placeholder-images.json';
import { IrrigationScheduleChart, allCropsData } from '@/components/irrigation-schedule-chart';
import { cn } from '@/lib/utils';
import { format, getMonth, getDate, isSameDay } from 'date-fns';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { useLanguage } from '@/context/language-context';
import { useCrop } from '@/context/crop-context';
import type { IrrigationData } from '@/components/irrigation-schedule-chart';


const heroImage = placeholderImages.placeholderImages.find(p => p.id === "dashboard-hero");

export default function DashboardPage() {
  const { crops, setCrops, deleteCrop } = useCrop();
  const [selectedCrop, setSelectedCrop] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();
  const { t, locale } = useLanguage();

  useState(() => {
    if (crops.length > 0 && !selectedCrop) {
      setSelectedCrop(crops[0].name);
    }
  });


  const handleCropChange = (cropName: string) => {
    setSelectedCrop(cropName);
    setSelectedDate(undefined);
  };
  
  const handleDeleteCrop = (e: React.MouseEvent, cropIdToDelete: number) => {
    e.stopPropagation(); // Prevent the crop from being selected when clicking delete
    deleteCrop(cropIdToDelete);

    // If the deleted crop was the selected one, select the first one in the new list
    const deletedCrop = crops.find(crop => crop.id === cropIdToDelete);
    if (deletedCrop && selectedCrop === deletedCrop.name) {
        const remainingCrops = crops.filter(c => c.id !== cropIdToDelete);
        if (remainingCrops.length > 0) {
            setSelectedCrop(remainingCrops[0].name);
        } else {
            setSelectedCrop(''); // No crops left
        }
    }
  };

  const selectedCropData = crops.find(crop => crop.name === selectedCrop);

  const {
    displayStageName,
    displayDateText,
    totalWaterVolume,
    irrigationDurationHours,
    seasonIrrigationDates,
    displayFullDate,
    selectedIrrigationPeriodDetails,
    periodHydroModule
  } = useMemo(() => {
    const cropSchedule = allCropsData[selectedCrop];
    if (!cropSchedule || !selectedCropData) {
      return {
        displayStageName: t('dashboard.noData'),
        displayDateText: '',
        totalWaterVolume: 0,
        irrigationDurationHours: 0,
        seasonIrrigationDates: [],
        displayFullDate: new Date(),
        selectedIrrigationPeriodDetails: null,
        periodHydroModule: 0
      };
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    const allDates = cropSchedule.data.map(d => {
        const monthIndex = monthNames.indexOf(d.month);
        return new Date(today.getFullYear(), monthIndex, d.dayOfMonth);
    });

    let targetDate: Date | undefined;
    let irrigationData: IrrigationData | undefined;

    if (selectedDate) {
      const foundData = cropSchedule.data.find(d => {
          const monthIndex = monthNames.indexOf(d.month);
          const date = new Date(today.getFullYear(), monthIndex, d.dayOfMonth);
          return isSameDay(date, selectedDate);
      });
      if (foundData) {
          irrigationData = foundData;
          const monthIndex = monthNames.indexOf(irrigationData.month);
          targetDate = new Date(today.getFullYear(), monthIndex, irrigationData.dayOfMonth);
      }
    } else {
        let nextDate: Date | undefined;
        for (const d of cropSchedule.data) {
            const monthIndex = monthNames.indexOf(d.month);
            const date = new Date(today.getFullYear(), monthIndex, d.dayOfMonth);
            if (date >= today) {
                nextDate = date;
                irrigationData = d;
                break;
            }
        }
        if (!nextDate && cropSchedule.data.length > 0) {
            const firstData = cropSchedule.data[0];
            const monthIndex = monthNames.indexOf(firstData.month);
            nextDate = new Date(today.getFullYear(), monthIndex, firstData.dayOfMonth);
            irrigationData = firstData;
        }
        targetDate = nextDate;
    }
    
    if (!irrigationData || !targetDate) {
        return {
          displayStageName: t('dashboard.noData'),
          displayDateText: t('dashboard.invalidDate'),
          totalWaterVolume: 0,
          irrigationDurationHours: 0,
          seasonIrrigationDates: allDates,
          displayFullDate: new Date(),
          selectedIrrigationPeriodDetails: null,
          periodHydroModule: 0
        };
    }

    let dateText = `${irrigationData.startDate} – ${irrigationData.endDate}`;

    const fieldSizeHa = selectedCropData.area || 0; // Area is in hectares
    
    // Correct calculation: Volume (m³) = Water Norm (m³/ha) * Field Area (ha)
    const totalWaterVolumeM3 = irrigationData.waterVolume * fieldSizeHa;

    const periodHydroModuleLpsHa = irrigationData.hydroModule;
    
    let durationHours = 0;
    // total flow for the field in l/s
    const totalFlowLps = periodHydroModuleLpsHa * fieldSizeHa;
    if (totalFlowLps > 0) {
      const totalWaterLiters = totalWaterVolumeM3 * 1000;
      const totalSeconds = totalWaterLiters / totalFlowLps;
      durationHours = totalSeconds / 3600;
    }

    return {
        displayStageName: irrigationData.description,
        displayDateText: dateText,
        totalWaterVolume: totalWaterVolumeM3,
        irrigationDurationHours: durationHours,
        seasonIrrigationDates: allDates,
        displayFullDate: targetDate,
        selectedIrrigationPeriodDetails: irrigationData,
        periodHydroModule: periodHydroModuleLpsHa,
    };

  }, [selectedCrop, selectedCropData, selectedDate, t, locale]);
  
  const handleDateSelect = (date: Date | undefined) => {
    if (date && seasonIrrigationDates.some(d => isSameDay(d, date))) {
        setSelectedDate(date);
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <Card className="relative overflow-hidden border-0 shadow-lg h-80">
        <Image
          src={heroImage?.imageUrl || "https://picsum.photos/seed/10/1200/400"}
          alt={heroImage?.description || "Зеленое поле под чистым небом"}
          data-ai-hint={heroImage?.imageHint || "farm field"}
          fill
          className="object-cover"
        />
        <div className="relative bg-gradient-to-t from-black/70 via-black/50 to-transparent p-8 md:p-12 h-full flex flex-col justify-end">
          <div className="max-w-2xl text-white">
            <h1 className="font-headline text-3xl font-bold md:text-4xl lg:text-5xl drop-shadow-md">
              {t('dashboard.welcome')}
            </h1>
            <p className="mt-2 text-lg text-gray-200 drop-shadow-sm">
              {t('dashboard.welcome.desc')}
            </p>
            <Button asChild className="mt-6" size="lg">
              <Link href="/ai-recommendations">
                {t('dashboard.getStarted')} <ArrowRight className="ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Popover>
          <PopoverTrigger asChild>
            <Card className="cursor-pointer hover:bg-secondary transition-colors">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{selectedDate ? t('dashboard.selectedIrrigation') : t('dashboard.nextIrrigation')}</CardTitle>
                <CalendarClock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{displayDateText}</div>
                <p className="text-xs text-muted-foreground">{`${t('dashboard.stagePrefix')} ${displayStageName}`}</p>
              </CardContent>
            </Card>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
             <div className="p-2 flex justify-end">
                <Button variant="ghost" size="sm" onClick={() => setSelectedDate(undefined)} disabled={!selectedDate}>
                    <X className="w-4 h-4 mr-2" />
                    {t('dashboard.clear')}
                </Button>
             </div>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={handleDateSelect}
              defaultMonth={displayFullDate}
              modifiers={{
                irrigationDay: seasonIrrigationDates,
              }}
              modifiersClassNames={{
                irrigationDay: "bg-primary/20 text-primary-foreground",
              }}
              className="rounded-md border"
              classNames={{
                day_selected: "bg-primary text-primary-foreground hover:bg-primary/90 focus:bg-primary/90",
              }}
            />
            {selectedIrrigationPeriodDetails && (
                 <div className="p-4 border-t text-sm space-y-2">
                    <h4 className="font-semibold">{t('dashboard.periodDetails')}</h4>
                    <p className='text-muted-foreground'>{selectedIrrigationPeriodDetails.description}</p>
                    <div className='flex justify-between'><span>{t('dashboard.periodDates')}:</span> <strong>{selectedIrrigationPeriodDetails.startDate} - {selectedIrrigationPeriodDetails.endDate} ({selectedIrrigationPeriodDetails.durationDays} {t('dashboard.days')})</strong></div>
                    <div className='flex justify-between'><span>{t('dashboard.waterNorm')}:</span> <strong>{selectedIrrigationPeriodDetails.waterVolume} {t('dashboard.waterNormUnit')}</strong></div>
                    <div className='flex justify-between'><span>{t('dashboard.hydromodule')}:</span> <strong>{selectedIrrigationPeriodDetails.hydroModule} {t('dashboard.hydromoduleUnit')}</strong></div>
                 </div>
            )}
          </PopoverContent>
        </Popover>
        <Popover>
            <PopoverTrigger asChild>
                <Card className="cursor-pointer hover:bg-secondary transition-colors">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">{t('dashboard.pumpPower')}</CardTitle>
                        <Waves className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{periodHydroModule.toFixed(2)} <span className='text-base font-normal'>{t('dashboard.hydromoduleUnit')}</span></div>
                        <p className="text-xs text-muted-foreground">{t('dashboard.pumpPowerDesc')}</p>
                    </CardContent>
                </Card>
            </PopoverTrigger>
            <PopoverContent>
                <h4 className="font-semibold mb-2">{t('dashboard.pumpPower')}</h4>
                <p className="text-sm text-muted-foreground">{t('dashboard.pumpPowerPopover')}</p>
            </PopoverContent>
        </Popover>
        <Popover>
            <PopoverTrigger asChild>
                <Card className="cursor-pointer hover:bg-secondary transition-colors">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">{t('dashboard.totalIrrigationVolume')}</CardTitle>
                        <Droplet className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{totalWaterVolume.toFixed(0)} <span className="text-base font-normal">{t('dashboard.totalIrrigationVolumeUnit')}</span></div>
                        <p className="text-xs text-muted-foreground">{t('dashboard.totalIrrigationVolumeDesc', { area: selectedCropData?.area || 0, crop: selectedCrop })}</p>
                    </CardContent>
                </Card>
            </PopoverTrigger>
             <PopoverContent>
                <h4 className="font-semibold mb-2">{t('dashboard.volumeCalcTitle')}</h4>
                <p className="text-sm text-muted-foreground mb-4">{t('dashboard.volumeCalcDesc')}</p>
                <pre className="mt-1 p-2 bg-muted rounded-md text-xs whitespace-pre-wrap">{`Объем (м³) = Меъёри об (м³/га) * Масоҳат (га)`}</pre>
            </PopoverContent>
        </Popover>
         <Popover>
            <PopoverTrigger asChild>
                <Card className="cursor-pointer hover:bg-secondary transition-colors">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">{t('dashboard.irrigationSettings')}</CardTitle>
                        <Clock className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{irrigationDurationHours > 0 ? irrigationDurationHours.toFixed(1) : '-'} <span className="text-base font-normal">{t('dashboard.irrigationSettingsUnit')}</span></div>
                        <p className="text-xs text-muted-foreground">{t('dashboard.irrigationSettingsDesc')}</p>
                    </CardContent>
                </Card>
            </PopoverTrigger>
             <PopoverContent>
                <h4 className="font-semibold mb-2">{t('dashboard.durationCalcTitle')}</h4>
                <p className="text-sm text-muted-foreground mb-4">{t('dashboard.durationCalcDesc')}</p>
                <pre className="mt-1 p-2 bg-muted rounded-md text-xs whitespace-pre-wrap">{`Давомнокӣ (соат) = (Ҳаҷм (м³) * 1000) / (Сарф (л/с) * 3600)`}</pre>
            </PopoverContent>
        </Popover>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
            <IrrigationScheduleChart selectedCrop={selectedCrop} />
        </div>
        <Card>
          <CardHeader>
            <CardTitle>{t('dashboard.myCrops')}</CardTitle>
            <CardDescription>{t('dashboard.myCropsDesc')}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
            {crops.map((crop) => (
              <div 
                key={crop.id}
                onClick={() => handleCropChange(crop.name)}
                className={cn(
                  "flex items-center justify-between gap-4 p-2 rounded-lg cursor-pointer transition-colors hover:bg-secondary/80",
                  selectedCrop === crop.name && "bg-secondary"
                )}
              >
                <div className="flex items-center gap-4">
                    <Image
                    src={crop.image || "https://picsum.photos/seed/crop-default/80/80"}
                    alt={crop.name}
                    data-ai-hint={crop.imageHint || 'культура'}
                    width={64}
                    height={64}
                    className="rounded-lg object-cover aspect-square"
                    />
                    <div>
                    <h4 className="font-semibold">{locale === 'tj' ? crop.name_tj : crop.name}</h4>
                    <p className="text-sm text-muted-foreground">{crop.area} га</p>
                    <Badge variant="outline" className="mt-1">{locale === 'tj' ? crop.stage_tj : crop.stage}</Badge>
                    </div>
                </div>
                 <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 rounded-full shrink-0"
                    onClick={(e) => handleDeleteCrop(e, crop.id)}
                    >
                    <X className="h-4 w-4 text-muted-foreground" />
                    <span className="sr-only">Удалить {crop.name}</span>
                </Button>
              </div>
            ))}
             {crops.length === 0 && (
                <div className="text-center text-muted-foreground p-8">
                    <p>Зироатҳо нест.</p>
                </div>
            )}
          </CardContent>
        </Card>
      </div>

      {selectedCropData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5 text-primary" />
              {t('dashboard.irrigationDetails', { crop: locale === 'tj' ? selectedCropData.name_tj : selectedCropData.name })}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              {locale === 'tj' ? selectedCropData.irrigationNotes_tj : selectedCropData.irrigationNotes}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
