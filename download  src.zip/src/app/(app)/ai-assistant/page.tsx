import { AiAssistantChat } from "@/components/ai-assistant-chat";
import { Bot } from "lucide-react";

export default function AiAssistantPage() {
  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="flex items-center gap-4 mb-4">
        <Bot className="w-8 h-8 text-muted-foreground" />
        <h1 className="font-headline text-3xl font-semibold">Ёрдамчии Оби ман</h1>
      </div>
       <p className="text-muted-foreground mb-6">
        Аз ёрдамчии зеҳни сунъӣ оид ба масъалаҳои обёрӣ, кишоварзӣ ва идоракунии об савол диҳед.
      </p>
      <AiAssistantChat />
    </div>
  );
}
