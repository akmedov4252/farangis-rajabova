import { WaterUsePlannerForm } from '@/components/water-use-planner-form';

export default function WaterUsePlannerPage() {
  return <WaterUsePlannerForm />;
}
