'use client';

import { CanalEfficiencyCalculator } from "@/components/canal-efficiency-calculator";
import { CanalFlowCalculator } from "@/components/canal-flow-calculator";
import { WaterDistributionPlanner } from "@/components/water-distribution-planner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calculator, Waves, Percent, Settings } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useLanguage } from "@/context/language-context";

export default function CanalCalculatorPage() {
  const { t } = useLanguage();
  return (
    <div className="max-w-4xl mx-auto flex flex-col gap-8">
       <div className="flex items-center gap-4 mb-4">
        <Settings className="w-8 h-8 text-muted-foreground" />
        <h1 className="font-headline text-3xl font-semibold">{t('canal.title')}</h1>
      </div>

      <Accordion type="single" collapsible className="w-full space-y-4">
        <AccordionItem value="item-1">
           <Card>
            <AccordionTrigger className="p-6 hover:no-underline">
                <CardHeader className="p-0 text-left">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-primary/10 rounded-lg">
                           <Calculator className="w-8 h-8 text-primary" />
                        </div>
                        <div>
                            <CardTitle className="font-headline text-2xl">{t('canal.calculator.title')}</CardTitle>
                            <CardDescription className="text-md mt-1">
                                {t('canal.calculator.desc')}
                            </CardDescription>
                        </div>
                    </div>
                </CardHeader>
            </AccordionTrigger>
            <AccordionContent>
                <CardContent>
                  <Tabs defaultValue="flow" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="flow">
                        <Waves className="mr-2" />
                        {t('canal.flowCalc.tab')}
                        </TabsTrigger>
                      <TabsTrigger value="efficiency">
                        <Percent className="mr-2" />
                        {t('canal.efficiencyCalc.tab')}
                      </TabsTrigger>
                    </TabsList>
                    <TabsContent value="flow">
                      <Card className="border-0 shadow-none">
                        <CardHeader>
                          <CardTitle>{t('canal.flowCalc.title')}</CardTitle>
                          <CardDescription>
                            {t('canal.flowCalc.desc')}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <CanalFlowCalculator />
                        </CardContent>
                      </Card>
                    </TabsContent>
                    <TabsContent value="efficiency">
                       <Card className="border-0 shadow-none">
                        <CardHeader>
                          <CardTitle>{t('canal.efficiencyCalc.title')}</CardTitle>
                          <CardDescription>
                            {t('canal.efficiencyCalc.desc')}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <CanalEfficiencyCalculator />
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </CardContent>
            </AccordionContent>
           </Card>
        </AccordionItem>
        <AccordionItem value="item-2">
             <Card>
                <AccordionTrigger className="p-6 hover:no-underline">
                     <CardHeader className="p-0 text-left">
                        <div className="flex items-center gap-4">
                             <div className="p-3 bg-primary/10 rounded-lg">
                               <Waves className="w-8 h-8 text-primary" />
                            </div>
                            <div>
                                <CardTitle className="font-headline text-2xl">{t('canal.planner.title')}</CardTitle>
                                <CardDescription className="text-md mt-1">
                                    {t('canal.planner.desc')}
                                </CardDescription>
                            </div>
                        </div>
                    </CardHeader>
                </AccordionTrigger>
                <AccordionContent>
                    <WaterDistributionPlanner />
                </AccordionContent>
             </Card>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

    