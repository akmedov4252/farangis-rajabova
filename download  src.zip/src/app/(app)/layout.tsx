'use client';
import type { PropsWithChildren } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Droplets,
  LayoutDashboard,
  Sparkles,
  AreaChart,
  User,
  LogOut,
  Leaf,
  Newspaper,
  Calculator,
  Settings,
  Menu as MenuIcon,
  FileClock,
} from 'lucide-react';

import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
  SidebarFooter,
  SidebarSeparator,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import placeholderImages from '@/lib/placeholder-images.json';
import { useAuth, useUser } from '@/firebase';
import { initiateAnonymousSignIn } from '@/firebase/non-blocking-login';
import { useEffect } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useLanguage } from '@/context/language-context';

export default function AppLayout({ children }: PropsWithChildren) {
  const pathname = usePathname();
  const auth = useAuth();
  const { user, isUserLoading } = useUser();
  const { t } = useLanguage();

  const navItems = [
    { href: '/dashboard', icon: LayoutDashboard, label: t('nav.dashboard') },
    { href: '/ai-recommendations', icon: Sparkles, label: t('nav.aiRecommendations') },
    { href: '/crop-water-calculator', icon: Leaf, label: t('nav.cropWaterCalculator') },
    { href: '/analytics', icon: AreaChart, label: t('nav.analytics') },
    { href: '/canal-calculator', icon: Calculator, label: t('nav.canalCalculator') },
    { href: '/water-use-planner', icon: FileClock, label: t('nav.waterUsePlanner') },
    { href: '/regional-water-analysis', icon: Droplets, label: t('nav.regionalWaterAnalysis') },
    { href: '/news', icon: Newspaper, label: t('nav.news') },
  ];

  useEffect(() => {
    if (!user && !isUserLoading) {
      initiateAnonymousSignIn(auth);
    }
  }, [user, isUserLoading, auth]);

  const userAvatar = placeholderImages.placeholderImages.find(p => p.id === "user-avatar");

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
          <div className="flex items-center gap-2 p-2">
            <Droplets className="text-primary" size={28} />
            <h1 className="text-2xl font-headline font-semibold">{t('header.title')}</h1>
          </div>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {navItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === item.href}
                  tooltip={item.label}
                >
                  <Link href={item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
         <SidebarFooter>
          <SidebarSeparator />
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton
                asChild
                isActive={pathname === '/settings'}
                tooltip={t('nav.settings')}
              >
                <Link href="/settings">
                  <Settings />
                  <span>{t('nav.settings')}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header className="sticky top-0 z-10 flex h-14 items-center justify-between border-b bg-background/80 px-4 backdrop-blur-sm lg:px-6">
          <div className="flex items-center gap-4">
            <div className="md:hidden">
               <SidebarTrigger className={cn(
                    "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
                    "h-9 px-3",
                    "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                )}>
                    <MenuIcon className="h-5 w-5" />
                    <span className="ml-2">{t('header.menu')}</span>
                </SidebarTrigger>
            </div>
             <div className="hidden md:flex items-center gap-2 text-lg font-semibold">
                <Droplets className="h-6 w-6 text-primary" />
                <span>{t('header.title')}</span>
              </div>
          </div>
          <div className="flex w-full items-center justify-end gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                  {isUserLoading ? (
                     <Skeleton className="h-9 w-9 rounded-full" />
                  ): (
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={userAvatar?.imageUrl} alt={userAvatar?.description} />
                      <AvatarFallback>Ф</AvatarFallback>
                    </Avatar>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {isUserLoading ? t('userMenu.loading') : user ? (user.isAnonymous ? t('userMenu.anonymous') : user.email || t('userMenu.farmer')) : t('userMenu.offline')}
                    </p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {isUserLoading ? '' : user ? `ID: ${user.uid.substring(0, 8)}...` : 'farmer@aquaplan.com'}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>{t('userMenu.profile')}</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{t('userMenu.logout')}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="flex-1 p-4 sm:p-6">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  );
}
