'use client';
import { CropWaterCalculator } from "@/components/crop-water-calculator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/context/language-context";
import { Leaf } from "lucide-react";

export default function CropWaterCalculatorPage() {
  const { t } = useLanguage();
  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader className="text-center">
            <div className="flex justify-center items-center mb-4">
                <Leaf className="w-12 h-12 text-primary" />
            </div>
            <CardTitle className="font-headline text-3xl">{t('cropCalculator.title')}</CardTitle>
            <CardDescription className="text-lg mt-2">
              {t('cropCalculator.description')}
            </CardDescription>
        </CardHeader>
        <CardContent>
            <CropWaterCalculator />
        </CardContent>
      </Card>
    </div>
  )
}

    