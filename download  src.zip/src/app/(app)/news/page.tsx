'use client';
import Image from 'next/image';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Newspaper } from 'lucide-react';
import placeholderImages from '@/lib/placeholder-images.json';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/context/language-context';

const newsItems = [
  {
    id: 1,
    title: 'Новые технологии орошения увеличили урожайность на 30%',
    title_tj: 'Технологияҳои нави обёрӣ ҳосилнокӣро 30% зиёд карданд',
    description: 'Использование систем капельного орошения и умных датчиков позволило фермерам Хатлонской области сократить расход воды и значительно повысить урожайность.',
    description_tj: 'Истифодаи системаҳои обёрии қатрагӣ ва санҷандаҳои ҳушманд ба деҳқонони вилояти Хатлон имкон дод, ки масрафи обро кам карда, ҳосилнокиро ба таври назаррас афзоиш диҳанд.',
    category: 'Технологии',
    category_tj: 'Технологияҳо',
    date: '24 июля 2024 г.',
    date_tj: '24 июли 2024',
    image: placeholderImages.placeholderImages.find(p => p.id === 'news-drip-irrigation')?.imageUrl,
    imageHint: 'drip irrigation farm',
  },
  {
    id: 2,
    title: 'Правительство выделило 10 миллионов сомони на модернизацию оросительных сетей',
    title_tj: 'Ҳукумат барои навсозии шабакаҳои обёрӣ 10 миллион сомонӣ ҷудо кард',
    description: 'В рамках государственной программы развития сельского хозяйства выделены дополнительные средства на ремонт и модернизацию межхозяйственных оросительных каналов, что улучшит эффективность водораспределения.',
    description_tj: 'Дар доираи барномаи давлатии рушди кишоварзӣ барои таъмир ва навсозии каналҳои обёрии байнихоҷагӣ маблағҳои иловагӣ ҷудо карда шуданд, ки самаранокии тақсимоти обро беҳтар мекунад.',
    category: 'Политика',
    category_tj: 'Сиёсат',
    date: '22 июля 2024 г.',
    date_tj: '22 июли 2024',
    image: placeholderImages.placeholderImages.find(p => p.id === 'news-canal-construction')?.imageUrl,
    imageHint: 'canal construction',
  },
  {
    id: 3,
    title: 'Прогноз погоды: на следующей неделе ожидается жара и засуха',
    title_tj: 'Пешгӯии обу ҳаво: ҳафтаи оянда гармӣ ва хушксолӣ дар назар аст',
    description: 'Синоптики предупреждают о высокой температуре и отсутствии осадков в большинстве регионов республики. Фермерам рекомендуется скорректировать режим полива.',
    description_tj: 'Синоптикҳо аз ҳарорати баланд ва набудани боришот дар аксари минтақаҳои ҷумҳурӣ огоҳ мекунанд. Ба деҳқонон тавсия дода мешавад, ки реҷаи обёриро ислоҳ кунанд.',
    category: 'Погода',
    category_tj: 'Обу ҳаво',
    date: '20 июля 2024 г.',
    date_tj: '20 июли 2024',
    image: placeholderImages.placeholderImages.find(p => p.id === 'news-dry-field')?.imageUrl,
    imageHint: 'dry cracked earth',
  },
    {
    id: 4,
    title: 'В Согдийской области испытывают новый засухоустойчивый сорт пшеницы',
    title_tj: 'Дар вилояти Суғд навъи нави гандуми ба хушкӣ тобовар озмуда мешавад',
    description: 'Ученые Академии сельскохозяйственных наук успешно испытали новый сорт пшеницы, адаптированный к условиям маловодья. Ожидается, что этот сорт повысит урожайность в засушливых регионах.',
    description_tj: 'Олимони Академияи илмҳои кишоварзӣ навъи нави гандумро, ки ба шароити камобӣ мутобиқ карда шудааст, бомуваффақият озмуданд. Интизор меравад, ки ин навъ ҳосилнокиро дар минтақаҳои хушк баланд бардорад.',
    category: 'Инновации',
    category_tj: 'Инноватсияҳо',
    date: '18 июля 2024 г.',
    date_tj: '18 июли 2024',
    image: placeholderImages.placeholderImages.find(p => p.id === 'crop-wheat')?.imageUrl,
    imageHint: 'wheat field',
  },
];

export default function NewsPage() {
  const { t, locale } = useLanguage();
  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <Newspaper className="w-8 h-8 text-muted-foreground" />
        <h1 className="font-headline text-3xl font-semibold">{t('news.title')}</h1>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {newsItems.map((item) => (
          <Card key={item.id} className="flex flex-col overflow-hidden">
            <div className="relative h-48 w-full">
                <Image
                    src={item.image || `https://picsum.photos/seed/${item.id}/400/250`}
                    alt={item.title}
                    data-ai-hint={item.imageHint}
                    fill
                    className="object-cover"
                />
            </div>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{locale === 'tj' ? item.category_tj : item.category}</Badge>
                <CardDescription>{locale === 'tj' ? item.date_tj : item.date}</CardDescription>
              </div>
              <CardTitle className="text-xl font-bold font-headline mt-2">{locale === 'tj' ? item.title_tj : item.title}</CardTitle>
            </CardHeader>
            <CardContent className="flex-grow">
              <p className="text-muted-foreground">{locale === 'tj' ? item.description_tj : item.description}</p>
            </CardContent>
            <CardFooter>
                <Button asChild variant="link" className="p-0">
                    <Link href="#">
                        {t('news.readMore')}
                    </Link>
                </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}

    