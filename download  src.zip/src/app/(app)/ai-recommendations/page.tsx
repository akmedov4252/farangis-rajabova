'use client';
import { AiRecommendationForm } from "@/components/ai-recommendation-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings } from "lucide-react";
import { useLanguage } from "@/context/language-context";

export default function AiRecommendationsPage() {
  const { t } = useLanguage();
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <Settings className="w-8 h-8 text-muted-foreground" />
        <h1 className="font-headline text-3xl font-semibold">{t('recommendations.title')}</h1>
      </div>
      <AiRecommendationForm />
    </div>
  )
}

    