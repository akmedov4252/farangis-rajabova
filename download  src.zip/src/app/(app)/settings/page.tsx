'use client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeSwitcher } from "@/components/theme-switcher";
import { Settings, Info, Palette, Languages } from "lucide-react";
import { LanguageSwitcher } from "@/components/language-switcher";
import { useLanguage } from "@/context/language-context";

export default function SettingsPage() {
  const { t } = useLanguage();
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <Settings className="w-8 h-8 text-muted-foreground" />
        <h1 className="font-headline text-3xl font-semibold">{t('settings.title')}</h1>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Palette className="w-6 h-6 text-primary" />
            <CardTitle className="font-headline text-2xl">{t('settings.appearance')}</CardTitle>
          </div>
          <CardDescription>
            {t('settings.appearanceDesc')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ThemeSwitcher />
        </CardContent>
      </Card>
      
       <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Languages className="w-6 h-6 text-primary" />
            <CardTitle className="font-headline text-2xl">{t('settings.language')}</CardTitle>
          </div>
          <CardDescription>
            {t('settings.languageDesc')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <LanguageSwitcher />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Info className="w-6 h-6 text-primary" />
            <CardTitle className="font-headline text-2xl">{t('settings.about')}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 text-muted-foreground">
          <p dangerouslySetInnerHTML={{ __html: t('settings.aboutDesc') }} />
          <p>
            {t('settings.version')}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

    