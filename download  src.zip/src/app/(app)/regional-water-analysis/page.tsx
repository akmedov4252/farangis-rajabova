import { RegionalWaterAnalysis } from '@/components/regional-water-analysis';

export default function RegionalWaterAnalysisPage() {
  return <RegionalWaterAnalysis />;
}
