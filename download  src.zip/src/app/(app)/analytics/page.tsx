'use client';
import { AnalyticsDashboard } from "@/components/analytics-dashboard";
import { useLanguage } from "@/context/language-context";

export default function AnalyticsPage() {
    const { t } = useLanguage();
    return <AnalyticsDashboard t={t} />;
}

    