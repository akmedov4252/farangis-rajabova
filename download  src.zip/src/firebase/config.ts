export const firebaseConfig = {
  "projectId": "studio-7120169056-1a85a",
  "appId": "1:783464109460:web:e2fbc41d321ce8d019ab81",
  "apiKey": "AIzaSyC-AxVM3nbRV9SLyfNhv6J6oM0B1vZ_weg",
  "authDomain": "studio-7120169056-1a85a.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "783464109460"
};
