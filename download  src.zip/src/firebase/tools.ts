'use server';
import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { initializeFirebase } from '@/firebase';
import { getDocs, collection } from 'firebase/firestore';

// Initialize Firebase Admin SDK
const { firestore } = initializeFirebase();

export const getCanals = ai.defineTool(
  {
    name: 'getCanals',
    description: 'Рӯйхати ҳамаи каналҳои обёриро аз пойгоҳи додаҳо мегирад. Инро барои ҷавоб додан ба саволҳо дар бораи каналҳои мушаххас истифода баред.',
    inputSchema: z.object({
        basin: z.string().optional().describe("Ҳавза барои филтр кардани каналҳо, агар лозим бошад."),
    }),
    outputSchema: z.array(z.object({
        id: z.string(),
        name: z.string(),
        location: z.string(),
        directorate: z.string(),
        capacity: z.number(),
    })),
  },
  async (input) => {
    try {
      const canalsCollection = collection(firestore, 'canals');
      const canalSnapshot = await getDocs(canalsCollection);
      const canalsList = canalSnapshot.docs.map(doc => ({
        id: doc.id,
        name: doc.data().name,
        location: doc.data().location,
        directorate: doc.data().directorate,
        capacity: doc.data().capacity,
      }));

      if (input?.basin) {
        return canalsList.filter(canal => canal.location.toLowerCase() === input.basin?.toLowerCase());
      }
      
      return canalsList;
    } catch (error) {
      console.error('Error fetching canals:', error);
      // In a real app, you might want to return a more structured error.
      // For the LLM, returning an empty array or a message might be enough.
      return [];
    }
  }
);
