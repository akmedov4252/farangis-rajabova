"use client";

import { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import placeholderImages from '@/lib/placeholder-images.json';

export interface Crop {
  id: number;
  name: string;
  name_tj: string;
  area: number;
  stage: string;
  stage_tj: string;
  image?: string;
  imageHint?: string;
  irrigationNotes: string;
  irrigationNotes_tj: string;
}

interface CropContextType {
  crops: Crop[];
  setCrops: (crops: Crop[]) => void;
  addCrop: (crop: Omit<Crop, 'id'> & { id?: number }) => void;
  deleteCrop: (cropId: number) => void;
}

const initialCrops: Crop[] = [
    { 
    id: 1, 
    name: 'Гандум', 
    name_tj: 'Гандум',
    area: 10, // ha
    stage: 'Налив зерна', 
    stage_tj: 'Пур шудани дон',
    image: placeholderImages.placeholderImages.find(p => p.id === "crop-wheat")?.imageUrl, 
    imageHint: 'wheat field',
    irrigationNotes: 'Пшеница нуждается в воде, особенно в период выхода в трубку и колошения. Достаточный полив в эти периоды увеличивает количество зерен в каждом колосе. Последний полив на стадии налива зерна важен для веса зерна.',
    irrigationNotes_tj: 'Гандум ба об, махсусан дар давраи ба найча баромадан ва хушабандӣ, ниёз дорад. Обиёрии кофӣ дар ин давраҳо миқдори донро дар ҳар як хуша зиёд мекунад. Обиёрии охирин дар марҳилаи пур шудани дон барои вазни дон муҳим аст.'
  },
  { 
    id: 2, 
    name: 'Ҷуворимакка', 
    name_tj: 'Ҷуворимакка',
    area: 15, // ha
    stage: 'Вегетация', 
    stage_tj: 'Нашъунамо',
    image: placeholderImages.placeholderImages.find(p => p.id === "crop-corn")?.imageUrl, 
    imageHint: 'corn field',
    irrigationNotes: 'Самый критический период для полива кукурузы — это стадия цветения и появления початков. Недостаток воды в этот период может значительно снизить урожайность. Убедитесь, что почва на этой стадии постоянно влажная.',
    irrigationNotes_tj: 'Давраи муҳимтарин барои обёрии ҷуворимакка ин марҳилаи гулкунӣ ва пайдоиши сутаҳо мебошад. Норасоии об дар ин давра метавонад ҳосилро ба таври назаррас коҳиш диҳад. Боварӣ ҳосил кунед, ки хок дар ин марҳила доимо намнок аст.'
  },
  { 
    id: 3, 
    name: 'Лубиё', 
    name_tj: 'Лубиё',
    area: 20, // ha
    stage: 'Цветение', 
    stage_tj: 'Гулкунӣ',
    image: placeholderImages.placeholderImages.find(p => p.id === "crop-soybeans")?.imageUrl, 
    imageHint: 'soybean field',
    irrigationNotes: 'Соя чувствительна к водному стрессу в период формирования стручков и налива семян. Регулярный полив на этих этапах важен для получения крупных семян и хорошего урожая. Ее корневая система чувствительна к избыточному затоплению.',
    irrigationNotes_tj: 'Лубиё ба фишори об дар давраи ташаккули ғилофак ва пур шудани донҳо ҳассос аст. Обиёрии мунтазам дар ин марҳилаҳо барои ба даст овардани донҳои калон ва ҳосили хуб муҳим аст. Системаи решаи он ба зериобмонӣ ҳассос аст.'
  },
];


const CropContext = createContext<CropContextType | undefined>(undefined);

export function CropProvider({ children }: { children: ReactNode }) {
  const [crops, setCropsState] = useState<Crop[]>([]);

  useEffect(() => {
    try {
      const storedCrops = localStorage.getItem('userCrops');
      if (storedCrops) {
        setCropsState(JSON.parse(storedCrops));
      } else {
        setCropsState(initialCrops);
      }
    } catch (error) {
      console.error("Failed to parse crops from localStorage", error);
      setCropsState(initialCrops);
    }
  }, []);

  const setCrops = (newCrops: Crop[]) => {
    localStorage.setItem('userCrops', JSON.stringify(newCrops));
    setCropsState(newCrops);
  };

  const addCrop = (cropToAdd: Omit<Crop, 'id'> & { id?: number }) => {
    const newCrop = {
      ...cropToAdd,
      id: cropToAdd.id || Date.now(), // Ensure a unique ID
    };
    const newCrops = [...crops, newCrop];
    setCrops(newCrops);
  };

  const deleteCrop = (cropId: number) => {
    const newCrops = crops.filter(crop => crop.id !== cropId);
    setCrops(newCrops);
  };

  return (
    <CropContext.Provider value={{ crops, setCrops, addCrop, deleteCrop }}>
      {children}
    </CropContext.Provider>
  );
}

export function useCrop() {
  const context = useContext(CropContext);
  if (context === undefined) {
    throw new Error('useCrop must be used within a CropProvider');
  }
  return context;
}
