'use server';
/**
 * @fileOverview An AI assistant flow for the AquaPlan app.
 *
 * - assistant - A function that handles chat interactions.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { getCanals } from '@/firebase/tools';

const AssistantInputSchema = z.object({
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    content: z.array(z.object({ text: z.string() })),
  })),
});
export type AssistantInput = z.infer<typeof AssistantInputSchema>;

const AssistantOutputSchema = z.string();
export type AssistantOutput = z.infer<typeof AssistantOutputSchema>;


export async function assistant(input: AssistantInput): Promise<AssistantOutput> {
  const systemPrompt = `You are an expert AI assistant for the "Оби ман" (My Water) application. Your role is to help farmers, water specialists, and agricultural engineers in Tajikistan. Your responses must be in Tajik.

You are an expert in:
- Water resource management and irrigation scheduling.
- Crop water requirements and agricultural best practices.
- Analysis of water consumption and canal efficiency.
- Providing insights based on regional data from areas like Sirdaryo, Amu Darya, Zarafshon, etc.
- Summarizing relevant news and providing guidance.

You have access to tools that can retrieve data from the app's database. If a user asks a question about their data (e.g., "list my canals"), use the available tools to answer accurately.

Keep your answers concise, practical, and easy to understand for a diverse audience. Always respond in the Tajik language.`;

  const {output} = await ai.generate({
    model: 'googleai/gemini-2.5-flash',
    system: systemPrompt,
    history: input.history,
    tools: [getCanals],
  });

  return output || "Лутфан, саволи худро такрор кунед.";
}
