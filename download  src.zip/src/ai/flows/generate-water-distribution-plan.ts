'use server';
/**
 * @fileOverview Инструмент на базе ИИ для создания индивидуальных планов распределения воды для фермеров.
 *
 * - generateWaterDistributionPlan - Функция, которая генерирует план распределения воды.
 * - WaterDistributionInput - Входной тип для функции generateWaterDistributionPlan.
 * - WaterDistributionOutput - Возвращаемый тип для функции generateWaterDistributionPlan.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const WaterDistributionInputSchema = z.object({
  cropType: z.string().describe('Тип орошаемой культуры.'),
  fieldSize: z.number().describe('Размер поля в гектарах.'),
  plantingDate: z.string().describe('Дата посева культуры.'),
  region: z.string().describe('Климатическая зона поля (например, полузасушливая, засушливая).'),
  irrigationMethod: z.string().describe('Используемый метод орошения (например, капельное, бороздовое).'),
});
export type WaterDistributionInput = z.infer<typeof WaterDistributionInputSchema>;

const WaterDistributionOutputSchema = z.object({
  waterAmount: z.number().describe('Рекомендуемое количество воды для использования в акр-дюймах.'),
  schedule: z.string().describe('Рекомендуемый график орошения (короткий, например, "Каждые 7 дней").'),
  notes: z.string().describe('Дополнительные примечания и рекомендации (очень кратко).'),
});
export type WaterDistributionOutput = z.infer<typeof WaterDistributionOutputSchema>;

export async function generateWaterDistributionPlan(
  input: WaterDistributionInput
): Promise<WaterDistributionOutput> {
  return generateWaterDistributionPlanFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateWaterDistributionPlanPrompt',
  input: {schema: WaterDistributionInputSchema},
  output: {schema: WaterDistributionOutputSchema},
  prompt: `You are an expert in agricultural irrigation. You are creating a plan for a farmer. The user's request may be in Russian or Tajik. You must respond in Russian.

You will generate a water distribution plan for a farmer based on the following information:

Crop Type: {{{cropType}}}
Field Size: {{{fieldSize}}} hectares
Irrigation Start Date: {{{plantingDate}}}
Climate Zone: {{{region}}}
Irrigation Method: {{{irrigationMethod}}}

Your response must be very concise.
- For the 'schedule', provide a simple, short frequency (e.g., 'Каждые 5 дней', 'Дважды в неделю'). DO NOT provide a long, multi-stage plan.
- For the 'notes', provide only the single most important, brief recommendation.

Provide the recommended amount of water, the simple irrigation schedule, and a very brief note.
`,
});

const generateWaterDistributionPlanFlow = ai.defineFlow(
  {
    name: 'generateWaterDistributionPlanFlow',
    inputSchema: WaterDistributionInputSchema,
    outputSchema: WaterDistributionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
