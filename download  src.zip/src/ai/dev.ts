import { config } from 'dotenv';
config();

import '@/ai/flows/generate-water-distribution-plan.ts';
